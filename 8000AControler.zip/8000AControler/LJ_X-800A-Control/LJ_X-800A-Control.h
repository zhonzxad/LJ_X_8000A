﻿
// LJ_X-800A-Control.h: PROJECT_NAME 应用程序的主头文件
//

#pragma once

#ifndef __AFXWIN_H__
	#error "在包含此文件之前包含“stdafx.h”以生成 PCH 文件"
#endif

#include "resource.h"		// 主符号


// CLJX800AControlApp:
// 有关此类的实现，请参阅 LJ_X-800A-Control.cpp
//

class CLJX800AControlApp : public CWinApp
{
public:
	CLJX800AControlApp();

// 重写
public:
	virtual BOOL InitInstance();

// 实现

	DECLARE_MESSAGE_MAP()
};

extern CLJX800AControlApp theApp;
