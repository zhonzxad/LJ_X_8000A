#pragma once

#  ifndef HC_LARGE_IMAGES
#    include <HALCONCpp/HalconCpp.h>
#    include <HALCONCpp/HDevThread.h>
#  else
#    include <HALCONCppxl/HalconCpp.h>
#    include <HALCONCppxl/HDevThread.h>
#  endif
#include <stdio.h>
#include <halconcpp/HDevThread.h>

#include "LJ_X-800A-ControlDlg.h"



using namespace HalconCpp;

class DealCam
{
public:
	DealCam();
	~DealCam();

public:
	void calculate_lines_gauss_parameters(HTuple hv_MaxLineWidth, HTuple hv_Contrast,
		HTuple *hv_Sigma, HTuple *hv_Low, HTuple *hv_High);
	// Chapter: Develop
	// Short Description: Open a new graphics window that preserves the aspect ratio of the given image. 
	void dev_open_window_fit_image(HObject ho_Image, HTuple hv_Row, HTuple hv_Column,
		HTuple hv_WidthLimit, HTuple hv_HeightLimit, HTuple *hv_WindowHandle);
	// Chapter: Develop
	// Short Description: Switch dev_update_pc, dev_update_var and dev_update_window to 'off'. 
	void dev_update_off();
	// Chapter: Develop
	// Short Description: Switch dev_update_pc, dev_update_var and dev_update_window to 'on'. 
	void dev_update_on();
	// Chapter: Graphics / Text
	// Short Description: This procedure writes a text message. 
	void disp_message(HTuple hv_WindowHandle, HTuple hv_String, HTuple hv_CoordSystem,
		HTuple hv_Row, HTuple hv_Column, HTuple hv_Color, HTuple hv_Box);
	// Local procedures 
	void ALL(HObject ho_Intensity, HObject ho_Height, HObject *ho_Image1, HObject *ho_Image2,
		HTuple hv_RegionMin, HTuple hv_RegionMax, HTuple hv_MatchPerimeter_all, HTuple hv_ChamWidthL_all,
		HTuple hv_ChamWidthR_all, HTuple hv_PelletLength_all, HTuple hv_ChamPhi_L_all,
		HTuple hv_ChamPhi_R_all, HTuple hv_CircDefectArea_all, HTuple hv_CircDefPercent_all,
		HTuple hv_xPixelSize, HTuple hv_zResolution, HTuple hv_filesindex, HTuple hv_m2,
		HTuple hv_yPixelSize);
	void all(HObject ho_Intensity, HObject ho_Height, HObject *ho_IntensMedian, HObject *ho_ROIRegion,
		HObject *ho_IntensCroped, HObject *ho_HeightCroped, HObject *ho_PreIntensCroped,
		HObject *ho_Cross, HObject *ho_CircDefect, HObject *ho_CircImageHt, HObject *ho_CircImageIns,
		HObject *ho_CircDefBorder, HTuple hv_RegionMin, HTuple hv_RegionMax, HTuple hv_MatchPerimeter_allOut,
		HTuple hv_ChamWidthL_allOut, HTuple hv_ChamWidthR_allOut, HTuple hv_PelletLength_allOut,
		HTuple hv_ChamPhi_L_allOut, HTuple hv_ChamPhi_R_allOut, HTuple hv_CircDefectArea_allOut,
		HTuple hv_CircDefPercent_allOut, HTuple hv_MatchPerimeter_all, HTuple hv_ChamWidthL_all,
		HTuple hv_ChamWidthR_all, HTuple hv_PelletLength_all, HTuple hv_ChamPhi_L_all,
		HTuple hv_ChamPhi_R_all, HTuple hv_CircDefectArea_all, HTuple hv_CircDefPercent_all,
		HTuple hv_xPixelSize, HTuple hv_zResolution, HTuple hv_filesindex, HTuple hv_m2,
		HTuple hv_yPixelSize, HTuple *hv_PelletExist, HTuple *hv_IntensWidth, HTuple *hv_IntensHeight,
		HTuple *hv_WindowHandle, HTuple *hv_ROIRegionNum, HTuple *hv_NG, HTuple *hv_MatchPerimeter,
		HTuple *hv_ChamWidthL, HTuple *hv_ChamWidthR, HTuple *hv_PelletLength, HTuple *hv_ChamPhi_L,
		HTuple *hv_ChamPhi_R, HTuple *hv_CircDefectArea, HTuple *hv_CircDefPercent, HTuple *hv_MatchPerimeter_allOutOut,
		HTuple *hv_ChamWidthL_allOutOut, HTuple *hv_ChamWidthR_allOutOut, HTuple *hv_PelletLength_allOutOut,
		HTuple *hv_ChamPhi_L_allOutOut, HTuple *hv_ChamPhi_R_allOutOut, HTuple *hv_CircDefectArea_allOutOut,
		HTuple *hv_CircDefPercent_allOutOut, HTuple *hv_HorProjection, HTuple *hv_VertProjection,
		HTuple *hv_Border_L, HTuple *hv_Border_R, HTuple *hv_ReachedBorder, HTuple *hv_MatchPerimeter_allOut1,
		HTuple *hv_ChamWidthL_allOut1, HTuple *hv_ChamWidthR_allOut1, HTuple *hv_PelletLength_allOut1,
		HTuple *hv_ChamPhi_L_allOut1, HTuple *hv_ChamPhi_R_allOut1, HTuple *hv_CircDefectArea_allOut1,
		HTuple *hv_CircDefPercent_allOut1, HTuple *hv_HdRowAll_L, HTuple *hv_HdRowAll_R,
		HTuple *hv_ColEdgeLL, HTuple *hv_ColEdgeLR, HTuple *hv_ColEdgeRL, HTuple *hv_ColEdgeRR,
		HTuple *hv_Col_LR, HTuple *hv_Col_RL, HTuple *hv_ChamExist_L, HTuple *hv_ChamExist_R,
		HTuple *hv_ChamCrackL, HTuple *hv_ChamCrackR, HTuple *hv_CircHtStand, HTuple *hv_ValidDefArea);
	void AllEdges(HObject ho_Regionselect, HObject ho_IntensCroped, HTuple hv_region_number,
		HTuple hv_IntensWidth, HTuple hv_IntensHeight, HTuple *hv_HdColEdgeLL, HTuple *hv_HdColEdgeLR,
		HTuple *hv_HdColEdgeRL, HTuple *hv_HdColEdgeRR, HTuple *hv_HdRowAll, HTuple *hv_HdHeight,
		HTuple *hv_RtCenterColAll, HTuple *hv_HdWidthAll, HTuple *hv_ChamExist_L, HTuple *hv_ChamExist_R,
		HTuple *hv_ChamCrackL, HTuple *hv_ChamCrackR);
	void AllEdges_COPY_1(HObject ho_Regionselect, HObject ho_IntensMedian, HTuple hv_region_number,
		HTuple hv_IntensWidth, HTuple hv_IntensHeight, HTuple *hv_HdColEdgeLL, HTuple *hv_HdColEdgeLR,
		HTuple *hv_HdColEdgeRL, HTuple *hv_HdColEdgeRR, HTuple *hv_HdRowAll, HTuple *hv_HdHeight,
		HTuple *hv_RtCenterColAll, HTuple *hv_HdWidthAll);
	void camera(HObject ho_Intensity, HObject ho_Height, HObject *ho_IntensMedian, HObject *ho_ROIRegion,
		HObject *ho_IntensCroped, HObject *ho_HeightCroped, HObject *ho_PreIntensCroped,
		HObject *ho_Cross1, HObject *ho_Cross2, HObject *ho_Cross3, HObject *ho_Cross4,
		HObject *ho_ImageOut1, HObject *ho_CircDefect, HObject *ho_CircImageHt, HObject *ho_CircImageIns,
		HObject *ho_CircDefBorder, HObject *ho_ImageOut2, HTuple *hv_PelletExist, HTuple *hv_ReachedBorder,
		HTuple *hv_RegionMax, HTuple *hv_RegionMin, HTuple *hv_NG, HTuple *hv_xPixelSize,
		HTuple *hv_yPixelSize, HTuple *hv_zResolution, HTuple *hv_MatchPerimeter_all,
		HTuple *hv_ChamWidthL_all, HTuple *hv_ChamWidthR_all, HTuple *hv_PelletLength_all,
		HTuple *hv_ChamPhi_L_all, HTuple *hv_ChamPhi_R_all, HTuple *hv_CircDefectArea_all,
		HTuple *hv_CircDefPercent_all, HTuple *hv_Volume_all, HTuple *hv_ChamWidthL,
		HTuple *hv_ChamWidthR, HTuple *hv_ChamPhi_L, HTuple *hv_ChamPhi_R, HTuple *hv_PelletLength,
		HTuple *hv_CircDefPercent, HTuple *hv_IntensWidth, HTuple *hv_IntensHeight, HTuple *hv_WindowHandle,
		HTuple *hv_ROIRegionNum, HTuple *hv_MatchPerimeter, HTuple *hv_CircDefectArea,
		HTuple *hv_HorProjection, HTuple *hv_VertProjection, HTuple *hv_Border_L, HTuple *hv_Border_R,
		HTuple *hv_HdRowAll_L, HTuple *hv_HdRowAll_R, HTuple *hv_ColEdgeLL, HTuple *hv_ColEdgeLR,
		HTuple *hv_ColEdgeRL, HTuple *hv_ColEdgeRR, HTuple *hv_Col_LR, HTuple *hv_Col_RL,
		HTuple *hv_ChamExist_L, HTuple *hv_ChamExist_R, HTuple *hv_ChamCrackL, HTuple *hv_ChamCrackR,
		HTuple *hv_CircHtStand, HTuple *hv_ValidDefArea);
	void Camera1(HObject ho_Intensity, HObject ho_Height, HObject *ho_ImageOut1, HObject *ho_ImageOut2,
		HTuple *hv_ChamWidthL, HTuple *hv_ChamWidthR, HTuple *hv_ChamPhi_L, HTuple *hv_ChamPhi_R,
		HTuple *hv_PelletLength, HTuple *hv_CircDefPercent);
	void ChamferPhi(HObject ho_HeightCroped, HTuple hv_Width_Cham, HTuple hv_Col_Cham,
		HTuple hv_HtWidth, HTuple hv_HtHeight, HTuple hv_HdRowAll, HTuple hv_zResolution,
		HTuple hv_xPixelSize, HTuple *hv_ChamPhi, HTuple *hv_Mode_Phi, HTuple *hv_EachRates,
		HTuple *hv_UniqTuple);
	void cir_select(HObject ho_Selected_maxDis, HObject *ho_Selected_cir);
	void CircumferenceSize(HObject ho_IntensCroped, HObject ho_HeightCroped, HTuple hv_RegionMin,
		HTuple hv_RegionMax, HTuple hv_IntensWidth, HTuple hv_IntensHeight, HTuple hv_xPixelSize,
		HTuple hv_zResolution, HTuple *hv_ChamWidthL, HTuple *hv_ChamWidthR, HTuple *hv_PelletLength,
		HTuple *hv_ChamPhi_L, HTuple *hv_ChamPhi_R, HTuple *hv_HdRowAll_L, HTuple *hv_HdRowAll_R,
		HTuple *hv_ColEdgeLL, HTuple *hv_ColEdgeLR, HTuple *hv_ColEdgeRL, HTuple *hv_ColEdgeRR,
		HTuple *hv_Col_LR, HTuple *hv_Col_RL, HTuple *hv_ChamExist_L, HTuple *hv_ChamExist_R,
		HTuple *hv_ChamCrackL, HTuple *hv_ChamCrackR);
	void ComputerTh(HObject ho_RtRoi, HObject ho_ImageMean, HTuple *hv_nTh);
	void Defect_Volume(HObject ho_CircImageHt, HObject ho_CircDefect, HTuple hv_xPixelSize,
		HTuple hv_yPixelSize, HTuple hv_zResolution, HTuple hv_CircHtStand, HTuple hv_ValidDefArea,
		HTuple *hv_Volume);
	void dside(HObject ho_Selected_cir, HObject *ho_result_crack, HTuple hv_width_crack,
		HTuple hv_n, HTuple hv_dis_crack);
	void find_crack_region(HObject ho_Image_crack_show, HObject *ho_re_crack, HTuple hv_height_crack,
		HTuple hv_width_crack, HTuple hv_Mean_length, HTuple *hv_kk);
	void find_edges(HObject ho_ImageMedian, HTuple hv_S_rec_number, HTuple hv_rec_Column,
		HTuple hv_S_rec_length, HTuple hv_S_rec_height, HTuple hv_Im_Width, HTuple hv_Im_Height,
		HTuple *hv_Col_edge1, HTuple *hv_Col_edge2, HTuple *hv_Col_edge3, HTuple *hv_Col_edge4,
		HTuple *hv_re_Row);
	void find_edges1(HObject ho_ImageMedian, HObject *ho_Rectangle, HTuple hv_S_rec_number,
		HTuple hv_rec_center_Row, HTuple hv_S_rec_length, HTuple hv_S_rec_height, HTuple hv_Im_Width,
		HTuple hv_Im_Height, HTuple *hv_Col_edge1, HTuple *hv_Col_edge2, HTuple *hv_Col_edge3,
		HTuple *hv_Col_edge4, HTuple *hv_re_Row);
	void find_Length(HTuple hv_Distance, HTuple *hv_Mean_length);
	void find_Length1(HTuple hv_Dist, HTuple *hv_Mean_length);
	void find_mode(HTuple hv_Distance, HTuple *hv_mode_Distance);
	void find_mode2(HTuple hv_Dist, HTuple *hv_re_num, HTuple *hv_uniq_Dist, HTuple *hv_sort_Dist,
		HTuple *hv_round_Dist, HTuple *hv_type_num, HTuple *hv_round_num, HTuple *hv_w,
		HTuple *hv_index_w);
	void find_tm(HTuple hv_Distance, HTuple *hv_mode_Distance);
	void find_tm1(HTuple hv_Dist, HTuple *hv_mode_Dist);
	void find_tp(HTuple hv_Distance_L1, HTuple hv_Distance_L2, HTuple hv_Distance_w1,
		HTuple hv_Distance_w2, HTuple *hv_Distance_L2Out, HTuple *hv_Distance_w1Out,
		HTuple *hv_Distance_w2Out, HTuple *hv_Index1);
	void find_tp1(HTuple hv_L2_Dist, HTuple hv_w1_Dist, HTuple hv_w2_Dist, HTuple hv_L1_Dist,
		HTuple *hv_L2out_Dist, HTuple *hv_w1out_Dist, HTuple *hv_w2out_Dist, HTuple *hv_Index1);
	void FindCircDefect(HObject ho_HeightCroped, HObject ho_IntensCroped, HObject *ho_CircDefect,
		HObject *ho_CircImageHt, HObject *ho_CircImageIns, HTuple hv_Col_LR, HTuple hv_MatchPerimeter,
		HTuple hv_Col_RL, HTuple hv_ChamExist_L, HTuple hv_ChamExist_R, HTuple *hv_CircDefectArea,
		HTuple *hv_CircDefPercent, HTuple *hv_CircHtStand, HTuple *hv_ValidDefArea);
	void FindCircRegion(HObject ho_X, HObject *ho_CircRegion);
	void findCrackRegion2(HObject ho_Image, HObject *ho_RtRoi, HObject *ho_Boundary,
		HObject *ho_ImageMean, HObject *ho_DarkRegion, HObject *ho_RegionIntersection,
		HObject *ho_DarkRegionConn, HObject *ho_SelectedRegions, HObject *ho_SelectedRegionsUnion,
		HObject *ho_RegionClosing1, HObject *ho_RegionClosing1Conn, HObject *ho_SelectedRegions2,
		HObject *ho_CrackRegions, HObject *ho_ObjectSelected, HObject *ho_RtObjectSelected,
		HObject *ho_RegionDilation, HObject *ho_RegionIntersection2, HObject *ho_ImageMeanReduced,
		HObject *ho_RtObjectSelectedDarkRegion, HObject *ho_RtObjectSelectedDarkRegionClosing,
		HObject *ho_RtObjectSelectedDarkRegionOpening, HObject *ho_RtObjectSelectedDarkRegionOpeningConn,
		HObject *ho_SelectedRegions3, HObject *ho_SelectedRegions3Union, HObject *ho_RegionClosing3,
		HObject *ho_RegionOpening3, HObject *ho_Rt1, HObject *ho_Rt2, HTuple hv_StartX,
		HTuple hv_EndX, HTuple hv_Border, HTuple *hv_Width, HTuple *hv_Height, HTuple *hv_Mean,
		HTuple *hv_Deviation, HTuple *hv_nTh, HTuple *hv_Number1, HTuple *hv_ii, HTuple *hv_Row1,
		HTuple *hv_Column1, HTuple *hv_Row2, HTuple *hv_Column2, HTuple *hv_Mean1, HTuple *hv_Deviation1,
		HTuple *hv_Row, HTuple *hv_Column, HTuple *hv_Radius, HTuple *hv_nW, HTuple *hv_Row11,
		HTuple *hv_Column11, HTuple *hv_Row21, HTuple *hv_Column21, HTuple *hv_MeanRt1,
		HTuple *hv_DeviationRt1, HTuple *hv_MeanRt2, HTuple *hv_DeviationRt2);
	void FindDefect_high(HObject ho_CircImage, HObject *ho_Defect_high, HTuple hv_Height);
	void FindDefect_Ht(HObject ho_CircImageHt, HObject *ho_Defect_high, HTuple hv_MatchPerimeter,
		HTuple hv_Col_LR, HTuple hv_Col_RL, HTuple hv_ValidDefArea);
	void FindDefect_Ins(HObject ho_CircImageIns, HObject ho_ROIRt, HObject *ho_Defect_light);
	void FindDefect_light(HObject ho_Y, HObject ho_CircRegion, HObject *ho_Defect_light);
	void FindEdges(HTuple hv_InputGray, HTuple *hv_Left, HTuple *hv_Right, HTuple *hv_CrackPoint);
	void findRegionCrack2(HObject ho_Image, HObject *ho_CrackBinImage, HObject *ho_CrackRegions,
		HTuple hv_StartX, HTuple hv_EndX, HTuple hv_n, HTuple *hv_CrackRegionsNumber);
	void getcrack(HObject ho_BinImage_crack, HObject *ho_result_crack, HTuple hv_n,
		HTuple hv_Line_MaxWidth, HTuple hv_width_crack);
	void Go2GenTL_ParseData(HObject ho_Image, HObject *ho_HeightMap, HObject *ho_Intensity,
		HTuple hv_Index, HTuple *hv_FrameCount, HTuple *hv_Timestamp, HTuple *hv_EncoderPosition,
		HTuple *hv_EncoderIndex, HTuple *hv_Inputs, HTuple *hv_xOffset, HTuple *hv_xResolution,
		HTuple *hv_yOffset, HTuple *hv_yResolution, HTuple *hv_zOffset, HTuple *hv_zResolution,
		HTuple *hv_Width, HTuple *hv_Length, HTuple *hv_HasIntensity, HTuple *hv_NumScans);
	void Go2GenTLStamp(HObject ho_Stamps, HTuple hv_Index, HTuple *hv_Value);
	void HeightConvert(HObject ho_Height3, HObject *ho_R, HObject *ho_G, HObject *ho_B,
		HObject *ho_Height);
	void image_deal(HObject ho_BinImage_crack, HTuple hv_width_crack, HTuple hv_n, HTuple hv_height_crack,
		HTuple hv_high_image, HTuple *hv_begin_row, HTuple *hv_end_row);
	void ImageCrop();
	void ImageCropping(HObject ho_ROIRegion, HObject ho_IntensMedian, HObject ho_Height,
		HObject ho_Intensity, HObject *ho_IntensCroped, HObject *ho_HeightCroped, HObject *ho_PreIntensCroped,
		HTuple hv_IntensHeight, HTuple hv_IntensWidth, HTuple *hv_MatchPerimeter);
	void max_distance(HObject ho_Selected_Length, HObject *ho_Selected_maxDis);
	void MeanPhi(HTuple hv_Dist, HTuple *hv_MeanV, HTuple *hv_ModeV, HTuple *hv_UniqTuple,
		HTuple *hv_EachRates);
	void MeanValue(HTuple hv_Dist, HTuple *hv_MeanV, HTuple *hv_IndexError_M, HTuple *hv_ModeV);
	void PelletEdges(HObject ho_Image, HObject *ho_ImageOut, HObject *ho_Rectangle_select,
		HObject *ho_Image_se, HObject *ho_ImageMedian, HObject *ho_Region, HObject *ho_RegionOpening,
		HObject *ho_Regions, HObject *ho_Regionselect, HObject *ho_Cross, HObject *ho_Cross1,
		HObject *ho_Cross2, HObject *ho_Cross3, HObject *ho_Cross4, HTuple hv_ImWidth,
		HTuple hv_RegionMin, HTuple hv_RegionMax, HTuple hv_PixelSize, HTuple *hv_ValidLength,
		HTuple *hv_NewImWidth, HTuple *hv_NewImHeight, HTuple *hv_thre_value, HTuple *hv_Value,
		HTuple *hv_region_number, HTuple *hv_PelletExist, HTuple *hv_RtCenterCol, HTuple *hv_SmallRtWidth,
		HTuple *hv_ColEdge1, HTuple *hv_ColEdge2, HTuple *hv_ColEdge3, HTuple *hv_ColEdge4,
		HTuple *hv_RowAll, HTuple *hv_W1, HTuple *hv_W2, HTuple *hv_L1, HTuple *hv_L2,
		HTuple *hv_NewL2, HTuple *hv_NewW1, HTuple *hv_NewW2, HTuple *hv_IndexError,
		HTuple *hv_Dist, HTuple *hv_Mean_length, HTuple *hv_PIXELwidth_L, HTuple *hv_ChamWidthR,
		HTuple *hv_PIXELwidth_R, HTuple *hv_ChamWidthL, HTuple *hv_PelletLength, HTuple *hv_ROI_width,
		HTuple *hv_Column_re_T, HTuple *hv_Col_e1, HTuple *hv_Col_e2, HTuple *hv_Col_e3,
		HTuple *hv_Col_e4);
	void Program1(HObject ho_Image, HObject *ho_ImgOri, HObject *ho_ImageOut, HObject *ho_Rectangle_select,
		HObject *ho_Image_se, HObject *ho_ImageMedian, HObject *ho_Region, HObject *ho_RegionOpening,
		HObject *ho_Regions, HObject *ho_Regionselect, HObject *ho_Cross, HObject *ho_Cross1,
		HObject *ho_Cross2, HObject *ho_Cross3, HObject *ho_Cross4, HObject *ho_CrackShow,
		HObject *ho_ShowRectangle, HObject *ho_ImageShow, HObject *ho_CrackBinImage,
		HObject *ho_CrackRegions, HObject *ho_ValidRecRegion, HObject *ho_Region2, HObject *ho_CrackCenters,
		HObject *ho_SelectCenters, HObject *ho_UnionCenters, HObject *ho_Unionlights,
		HObject *ho_CrackResult, HObject *ho_result_crack, HTuple hv_RegionMin, HTuple hv_RegionMax,
		HTuple hv_PixelSize, HTuple hv_n, HTuple hv_WidthCrack, HTuple *hv_ImWidth, HTuple *hv_ImHeight,
		HTuple *hv_ValidLength, HTuple *hv_NewImWidth, HTuple *hv_NewImHeight, HTuple *hv_thre_value,
		HTuple *hv_Value, HTuple *hv_region_number, HTuple *hv_PelletExist, HTuple *hv_RtCenterCol,
		HTuple *hv_SmallRtWidth, HTuple *hv_ColEdge1, HTuple *hv_ColEdge2, HTuple *hv_ColEdge3,
		HTuple *hv_ColEdge4, HTuple *hv_RowAll, HTuple *hv_W1, HTuple *hv_W2, HTuple *hv_L1,
		HTuple *hv_L2, HTuple *hv_NewL2, HTuple *hv_NewW1, HTuple *hv_NewW2, HTuple *hv_IndexError,
		HTuple *hv_Dist, HTuple *hv_Mean_length, HTuple *hv_PIXELwidth_L, HTuple *hv_ChamWidthR,
		HTuple *hv_PIXELwidth_R, HTuple *hv_ChamWidthL, HTuple *hv_PelletLength, HTuple *hv_ROI_width,
		HTuple *hv_Column_re_T, HTuple *hv_Col_e1, HTuple *hv_Col_e2, HTuple *hv_Col_e3,
		HTuple *hv_Col_e4, HTuple *hv_CracksNum, HTuple *hv_CracksLength, HTuple *hv_CracksLengthsSum,
		HTuple *hv_LineMaxWidth, HTuple *hv_StartX, HTuple *hv_EndX, HTuple *hv_HeightCrack,
		HTuple *hv_CrackRegionsNumber, HTuple *hv_CracksArea, HTuple *hv_MaxLineWidth,
		HTuple *hv_Contrast, HTuple *hv_Sigma, HTuple *hv_Low, HTuple *hv_High, HTuple *hv_CracksLengths,
		HTuple *hv_Pellet_exist, HTuple *hv_NG);
	void SelectTuple(HTuple hv_NewTuple, HTuple *hv_Mean, HTuple *hv_ErrorIndex);
	void TruePoints(HTuple hv_WT_L, HTuple hv_WT_R, HTuple hv_LT_Md, HTuple hv_LT_Pt,
		HTuple *hv_NewWT_L, HTuple *hv_NewWT_R, HTuple *hv_NewLT_Pt, HTuple *hv_IndexError_LT_Md);
	void TupleRates(HTuple hv_NeWTuple, HTuple *hv_SortTuple, HTuple *hv_RoundTuple,
		HTuple *hv_UniqTuple, HTuple *hv_TypeNum, HTuple *hv_EachRates, HTuple *hv_TupleNum,
		HTuple *hv_EachIndexs);
	void ValidRegion(HObject ho_CrackBinImage, HObject *ho_ValidRecRegion, HTuple hv_HeightCrack);

public:
	HObject  ho_DJ_Out, ho_QX_Out;
	CLJX800AControlDlg* mg_dlg;

public:
	void ToStartCamDeal(std::shared_ptr<HObject> hoHeightPtr, std::shared_ptr<HObject> hoIntensPtr,
		HalconCpp::HTuple hv_windowhandle1, HalconCpp::HTuple hv_windowhandle2, CLJX800AControlDlg *mg_dlg);


};

