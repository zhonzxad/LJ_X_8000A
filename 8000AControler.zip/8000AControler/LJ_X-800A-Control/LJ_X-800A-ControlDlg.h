﻿
// LJ_X-800A-ControlDlg.h: 头文件
//
#pragma once

#include <afx.h>
#include <vector>
#include <fstream>
#include <algorithm>
#include <iostream>
#include <iterator>
#include <Windows.h>
#include <sstream>
#include <string>
#include <iomanip>
#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include <chrono>
#include <thread>
#include <mutex>
#include <atomic>

#include "LJX8_IF.h"
#include "LJX8_ErrorCode.h"
#include "DeviceData.h"
#include "ThreadSafeBuffer.h"
#include "Define.h"

#include "halconcpp/HalconCpp.h"

using namespace HalconCpp;
using namespace std;

// CLJX800AControlDlg 对话框
class CLJX800AControlDlg : public CDialogEx
{
// 构造
public:
	CLJX800AControlDlg(CWnd* pParent = nullptr);	// 标准构造函数

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_LJ_X800ACONTROL_DIALOG };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV 支持


// 实现
protected:
	HICON m_hIcon;

	// 生成的消息映射函数
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()

public:
	CRect rc;

	decltype(std::chrono::steady_clock::now()) time1_{ std::chrono::steady_clock::now() };

public:
	

public:
	//是否可以清理收集区 默认为0不可清理
	std::atomic_bool Clear_StopMark = 0;
	//收集区是否收集够需要的轮廓
	std::atomic_bool ReceiveEnough = 0;
	//触发间隔
	int TriggerTimerInterval = 500;
	//要收集的轮廓数
	CString ProfileCount = L"1334";
	// 是否使用简单数组
	BOOL m_bIsUseSimpleArray = 1;
	// 高速保存文件路径
	CString SaveFilePath;		
	// 当前执行状态
	LONG lRcState;
	// 当前选择的传感头
	int m_nCurrentDeviceID = 0;
	// 以太网连接地址
	CString SensorIpStr = L"192.168.0.1";
	// 以太网连接端口号
	int PortNum = 24691;
	// 以太网高速连接端口号
	int HeighPortNum = 26492;
	// 收集轮廓序列号
	int ProfileStartNum = 1;
	// 发送起始位
	BYTE SendPosNum = 2;
	// 收集轮廓的起始位置（默认为0）
	int ProfileIndex = 0;
	// 图像的长和宽
	HalconCpp::HTuple	Img_Width, Img_Height;
	// 窗口显示句柄
	HalconCpp::HTuple	hv_windowhandle1, hv_windowhandle2, hv_windowhandle3, hv_windowhandle4;
	// 设置字体
	CFont font;
	// int型数字格式的收集轮廓数
	int ProfileCountNum = 0;
	// 数字格式已经接收轮廓数
	int HaveReceiveProfNum = 0;
	// 保存文件序号
	HalconCpp::HTuple hv_a = 0, hv_b = 0;
	// 保存文件地址（可更改）
	CString fileName;
	// 线程锁对象
	std::mutex mtx;
	std::mutex mtxCallBack;
	// C+++11标准检测样品是否到边界
	std::atomic_bool isMOXOnBoder = FALSE;
	// 检测暂停按钮动作
	std::atomic_bool isPauseBtn = FALSE;
	// 指示相机是否打开 默认为0没打开
	std::atomic_bool isCamOpen = FALSE;
	// int型保存文件数
	int SaveImgCount;

	typedef enum
	{
		SENDCOMMAND_NONE,												// 发送空 None
		SENDCOMMAND_REBOOT_CONTROLLER,									// 发送重启 Restart
		SENDCOMMAND_TRIGGER,											// 发送触发 Trigger
		SENDCOMMAND_START_MEASURE,										// 发送开始测量 Start measurement
		SENDCOMMAND_STOP_MEASURE,										// 发送停止测量 Stop measurement
		SENDCOMMAND_GET_PROFILE,										// 发送获取轮廓数据 Get profiles
		SENDCOMMAND_GET_BATCH_PROFILE,									// 发送获取批次配置文件 Get batch profiles
		SENDCOMMAND_REQUEST_STORAGE,									// 发送手动存储请求 Manual storage request
		SENDCOMMAND_INITIALIZE_HIGH_SPEED_DATA_ETHERNET_COMMUNICATION,	// 发送初始化以太网高速数据通信 Initialize Ethernet high-speed data communication
		SENDCOMMAND_PRE_START_HIGH_SPEED_DATA_COMMUNICATION,			// 发送开始高速数据通信之前要求准备 Request preparation before starting high-speed data communication
		SENDCOMMAND_START_HIGH_SPEED_DATA_COMMUNICATION,				// 发送开始高速数据通讯 Start high-speed data communication
	} SENDCOMMAND;
	SENDCOMMAND m_sendCommand; //发送命令

	
	
	

	int m_anProfReceiveCount[LJX8IF_GUI_DEVICE_COUNT];
	static CDeviceData m_aDeviceData[LJX8IF_GUI_DEVICE_COUNT];
	static LJX8IF_PROFILE_INFO m_aProfileInfo[];
	static BOOL m_bIsBufferFull[];
	static BOOL m_bIsStopCommunicationByError[];


	CString UpDateReceiveCount();
	void displaySend(int t, HalconCpp::HObject img);
	void set_display_font(HTuple hv_WindowHandle, HTuple hv_Size, HTuple hv_Font, HTuple hv_Bold, HTuple hv_Slant);
	void disp_message(HTuple hv_WindowHandle, HTuple hv_String, HTuple hv_CoordSystem, HTuple hv_Row, HTuple hv_Column, HTuple hv_Color, HTuple hv_Box);
	void displayImgInfo(int t, HTuple hv_ChamPhi_L, HTuple hv_ChamPhi_R,
		HTuple ChamWidthL, HTuple ChamWidthR, HTuple PelletLength, HTuple CircDefPercent);
	void OnDrawShowInfoSize(int t, std::shared_ptr<HalconCpp::HObject> img);
	void ShowImg(int t, HalconCpp::HObject * img);
	void XSleep(int nWaitInMsecs);
	void WriteLog(CString s);
	void InitializeDLL();					
	void InitializeConnectionInfo(int targetDeviceID);		
	void ChooseSavePatSingle();
	CString ChangeSaveFileName();
	void OpenEthernetSingle();
	void Communicationclose();
	void ClearAllHighspeedBuffer(int nDeviceId);
	void InitializehighspeeddatacommunicationSimplearray();		
	void Prestarthighspeeddatacommunication();
	void Startmeasure();
	void Stophighspeeddatacommunication();
	void Finalizehighspeeddatacommunication();
	void Stopmeasure();
	void Hispeedsaveasbitmapfile();
	BOOL CreateDirByName(CString filePath);
	BOOL TestFileIsHave(CString SaveFilePath);
	BOOL TestImgIsRunOutBorder(std::shared_ptr<HObject>  ho_Image);
	void TestRecIsEnoughAndSave(DWORD dwCountReceive, DWORD dwCount, DWORD dwNotify);
	void SaveImg(int SaveInfoMark, CString SaveFilePath, int hv_a, std::shared_ptr<HalconCpp::HObject> img);
	void VecToImgSaveAndShow();
	void OnBnClickedBtnOpencam();
	CString OpenChangePathDlg();
	CString GetSysTime();
	void SaveFile2TXT(CString filename, CString text);
	CString LoopPLCFileName(int hv_a, CString fileName);

	LJX8IF_ETHERNET_CONFIG GetEthernetConfig();
	LJX8IF_HIGH_SPEED_PRE_START_REQ getHighSpeedPreStartReq();

	static void ReceiveHighSpeedSimpleArray(LJX8IF_PROFILE_HEADER * pProfileHeaderArray, WORD * pHeightProfileArray,
		WORD * pLuminanceProfileArray, DWORD dwLuminanceEnable, DWORD dwProfileDataCount, DWORD dwCount, DWORD dwNotify, DWORD dwUser);
	void OnReceiveHighSpeedSimpleArray(LJX8IF_PROFILE_HEADER * pProfileHeaderArray, WORD * pHeightProfileArray,
		WORD * pLuminanceProfileArray, DWORD dwLuminanceEnable, DWORD dwProfileDataCount, DWORD dwCount, DWORD dwNotify, DWORD dwUser);

public:
	afx_msg void Starthighspeeddatacommunication();
	afx_msg void OnBnClickedBtnStartcam();
	afx_msg void OnBnClickedBtnClosecam();
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg void OnEnChangeLogshowEdit();
	afx_msg void OnDestroy();
	afx_msg void OnBnClickedButton1();
	afx_msg void OnBnClickedButton3();
	afx_msg void OnBnClickedButton2();
	afx_msg void OnBnClickedButLoopstart();
	afx_msg void OnEnChangeStaAddpath();
	afx_msg void OnBnClickedBtnPausecam();
	afx_msg void OnBnClickedButCleanlog();
	afx_msg void OnBnClickedRadNotplc();
	afx_msg void OnBnClickedRadPlc();
	afx_msg void OnEnChangeStaSavenum();
	afx_msg void OnBnClickedButTest();
};
