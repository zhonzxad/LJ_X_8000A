//Copyright (c) 2019 KEYENCE CORPORATION. All rights reserved.
#pragma once
#include "LJX8_IF.h"
#include "halconcpp/HalconCpp.h"
#include <vector>

using namespace std;
using namespace HalconCpp;

class CProfileSimpleArrayStore
{
private:
	static const int BATCH_FINALIZE_FLAG_BIT_COUNT = 16;
	CCriticalSection m_csDataAccess;
	DWORD m_dwCount;
	DWORD m_dwNotify;
	vector<WORD> m_vecProfileData;
	vector<WORD> m_vecLuminanceData;
	void SaveBitmap(DWORD dwIndex, DWORD dwCount, CString strPathBase);
	void SaveTiff(DWORD dwIndex, DWORD dwCount, CString strPathBase, CString SaveNum);
	void SaveBitmapCore(CString strFilePath, WORD* data, DWORD dwWidth, DWORD dwHeight);
	void SaveTiffCore(CString strFilePath, WORD* data, DWORD dwWidth, DWORD dwHeight);

public:
	vector<int> m_vecProfileData_bp;
	vector<int> m_vecLuminanceData_bp;

public:
	CProfileSimpleArrayStore();
	~CProfileSimpleArrayStore();
	bool m_bIsLuminanceEnable;
	int m_nDataWidth;
	int m_nBatchNo;
	DWORD GetCount();
	void AddCount(DWORD dwCount);
	DWORD GetNotify();
	void AddNotify(DWORD dwNotify);
	bool AddReceivedData(WORD* pwProfileBuffer, WORD* pwLuminanceBuffer, DWORD dwCount);
	void Clear();

	bool SaveDataAsImages(CString strFilePath, DWORD dwIndex, DWORD dwCount, CString SaveNum);
	void WriteTiffHeader(FILE* fTif, DWORD dwWidth, DWORD dwHeight);
	void WriteTiffTag(FILE* fTif, unsigned short kind, unsigned short dataType, unsigned int dataSize, unsigned int data);

	BOOL VerProfileToImage(std::shared_ptr<HObject> hoHeightPtr, std::shared_ptr<HObject> hoIntensPtr, DWORD dwIndex, DWORD dwCount);

	BOOL SaveDataImgToVector(DWORD dwIndex, DWORD dwCount);  //
	void SaveTiff(DWORD dwIndex, DWORD dwCount);
	void SaveTiffCore(std::vector<byte>& mem, WORD* data, DWORD dwWidth, DWORD dwHeight);
	void WriteTiffHeader(std::vector<byte>& mem, DWORD dwWidth, DWORD dwHeight);
	void WriteTiffTag(std::vector<byte>& mem, unsigned short kind, unsigned short dataType, unsigned int dataSize, unsigned int data);


public:

	// �洢�߶�ֵ������ֵ���ݵ��ڴ����
	std::vector<byte> mem_Height;
	std::vector<byte> mem_Intens;

	// �ڴ������ɵ�ͼƬ����
	//HalconCpp::HObject* ho_Height = new HalconCpp::HObject();
	//HalconCpp::HObject* ho_Intens = new HalconCpp::HObject();

};
