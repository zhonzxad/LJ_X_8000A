﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ 生成的包含文件。
// 供 LJX800AControl.rc 使用
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_LJ_X800ACONTROL_DIALOG      102
#define IDR_MAINFRAME                   128
#define IDI_ICON1                       130
#define IDC_BTN_OPENCAM                 1000
#define IDC_BTN_STARTCAM                1001
#define IDC_BTN_CLOSECAM                1002
#define IDC_BTN_PAUSECAM                1003
#define IDC_LOGSHOW_EDIT                1004
#define IDC_STA_ADDPATH                 1005
#define IDC_BUT_CHOOSESAVEPATH          1006
#define IDC_STA_SHOWHEIGHT              1007
#define IDC_STA_SHOWINTENS              1008
#define IDC_TXT_HEIGHT                  1009
#define IDC_TXT_INTENS                  1010
#define IDC_STATIC_RE                   1011
#define IDC_TXT_DJ                      1011
#define IDC_BUTTON1                     1012
#define IDC_BUTTON2                     1013
#define IDC_BUTTON3                     1014
#define IDC_BUTTON4                     1015
#define IDC_BUT_LOOPSTART               1015
#define IDC_STA_SAVENUM                 1016
#define IDC_TXT_QX                      1017
#define IDC_BUTTON6                     1018
#define IDC_BUT_TEST                    1018
#define IDC_CHK_CHOOSESAVEIMG           1019
#define IDC_CHK_ISSETPBYMORE            1020
#define IDC_BUTTON5                     1022
#define IDC_BUT_CLEANLOG                1022
#define IDC_CHECK1                      1023
#define IDC_CHK_ISSAVEFROMNUM           1023
#define IDC_RAD_NOTPLC                  1024
#define IDC_RAD_PLC                     1025
#define IDC_STA_SHOWDEALDJ              1027
#define IDC_STA_SHOWDEALQX              1028

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1029
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
