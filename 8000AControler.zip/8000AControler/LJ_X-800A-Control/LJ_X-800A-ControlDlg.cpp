﻿// LJ_X-800A-ControlDlg.cpp: 实现文件
//
#pragma once

#include "stdafx.h"
#include <afx.h>
#include <vector>
#include <fstream>
#include <algorithm>
#include <iostream>
#include <iterator>
#include <Windows.h>
#include <sstream>
#include <string>
#include <iomanip>
#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include <atomic>
#include <chrono>
#include <thread>
#include <mutex>
#include <io.h>
#include <direct.h>


#include "thread_pool.h"
#include "windows.h"
#include "LJ_X-800A-Control.h"
#include "LJ_X-800A-ControlDlg.h"
#include "DealCam.h"
#include "afxdialogex.h"

using namespace std;
using namespace HalconCpp;

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

CDeviceData CLJX800AControlDlg::m_aDeviceData[LJX8IF_GUI_DEVICE_COUNT];
LJX8IF_PROFILE_INFO CLJX800AControlDlg::m_aProfileInfo[LJX8IF_GUI_DEVICE_COUNT];
BOOL CLJX800AControlDlg::m_bIsBufferFull[LJX8IF_GUI_DEVICE_COUNT];
BOOL CLJX800AControlDlg::m_bIsStopCommunicationByError[LJX8IF_GUI_DEVICE_COUNT];
DealCam *mg_DealCam;

#define TimeTriggerStartID			1				//1号定时器负责启动
#define BufferFullID				2				//2号定时器为超时定时器
#define SaveImgID					3				//3号定时器为存图定时器

#define SensorIpStr					L"192.168.0.1"	//传感器地址
#define TriggerTimerInterval		500				//内部触发间隔
#define ProfileCount				L"1334"			//要收集的轮廓数
#define PortNum						24691			//端口号
#define HeighPortNum				24692			//高速端口号

#define ProfileStartNum				1				//轮廓收集起始位置
#define SendPosNum					2				//发送位起止
#define BUFFER_FULL_TIMER_INTERVAL	500				//缓冲区满检测时间
#define SaveImgIDInterval			25				//存图定时器间隔
//#define SaveImgPath					L"E:\\VS-Debug\\8000A-SelfControl\\image\\"
#define SaveImgPath					L"G:\\基恩士拍摄数据\\测试\\20200102"
#define SaveImgNumCount				60			//保存完多少张图片停止拍摄
#define MOXNum						20				//样品数

ThreadPool m_ThreadPool;

struct XSleep_Structure
{
	int duration;
	HANDLE evenHandle;
}mXSleep;

DWORD WINAPI XSleepThread(LPVOID pWaitTime)
{
	XSleep_Structure *sleep = (XSleep_Structure*)pWaitTime;
	mXSleep = *(XSleep_Structure*)pWaitTime;
	Sleep(sleep->duration);
	SetEvent(sleep->evenHandle);

	return 0;
}

CLJX800AControlDlg * g_pMainWnd = nullptr;

// CLJX800AControlDlg 对话框
// 构造对话框，初始化相关的变量
CLJX800AControlDlg::CLJX800AControlDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_LJ_X800ACONTROL_DIALOG, pParent)
	, Clear_StopMark(FALSE)
	, ReceiveEnough(0)
	, m_bIsUseSimpleArray(1)
	, m_nCurrentDeviceID(0)
	, ProfileIndex(0)
	, isCamOpen(FALSE)
	, hv_a(0)
	, isPauseBtn(FALSE)
	, isMOXOnBoder(FALSE)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CLJX800AControlDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CLJX800AControlDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BTN_OPENCAM, &CLJX800AControlDlg::OnBnClickedBtnOpencam)
	ON_BN_CLICKED(IDC_BTN_STARTCAM, &CLJX800AControlDlg::OnBnClickedBtnStartcam)
	ON_BN_CLICKED(IDC_BTN_CLOSECAM, &CLJX800AControlDlg::OnBnClickedBtnClosecam)
	ON_BN_CLICKED(IDC_BUT_CHOOSESAVEPATH, &CLJX800AControlDlg::ChooseSavePatSingle)
	ON_WM_TIMER()
	ON_EN_CHANGE(IDC_LOGSHOW_EDIT, &CLJX800AControlDlg::OnEnChangeLogshowEdit)
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_BUTTON1, &CLJX800AControlDlg::OnBnClickedButton1)
	ON_BN_CLICKED(IDC_BUTTON3, &CLJX800AControlDlg::OnBnClickedButton3)
	ON_BN_CLICKED(IDC_BUTTON2, &CLJX800AControlDlg::OnBnClickedButton2)
	ON_BN_CLICKED(IDC_BUT_LOOPSTART, &CLJX800AControlDlg::OnBnClickedButLoopstart)
ON_EN_CHANGE(IDC_STA_ADDPATH, &CLJX800AControlDlg::OnEnChangeStaAddpath)
ON_BN_CLICKED(IDC_BTN_PAUSECAM, &CLJX800AControlDlg::OnBnClickedBtnPausecam)
ON_BN_CLICKED(IDC_BUT_CLEANLOG, &CLJX800AControlDlg::OnBnClickedButCleanlog)
ON_BN_CLICKED(IDC_RAD_NOTPLC, &CLJX800AControlDlg::OnBnClickedRadNotplc)
ON_BN_CLICKED(IDC_RAD_PLC, &CLJX800AControlDlg::OnBnClickedRadPlc)
ON_EN_CHANGE(IDC_STA_SAVENUM, &CLJX800AControlDlg::OnEnChangeStaSavenum)
ON_BN_CLICKED(IDC_BUT_TEST, &CLJX800AControlDlg::OnBnClickedButTest)
END_MESSAGE_MAP()

// CLJX800AControlDlg 消息处理程序

BOOL CLJX800AControlDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// 将“关于...”菜单项添加到系统菜单中。

	// IDM_ABOUTBOX 必须在系统命令范围内。
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != nullptr)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// 设置此对话框的图标。  当应用程序主窗口不是对话框时，框架将自动
	//  执行此操作
	SetIcon(m_hIcon, TRUE);			// 设置大图标
	SetIcon(m_hIcon, FALSE);		// 设置小图标

	//ShowWindow(SW_MINIMIZE);

	// TODO: 在此添加额外的初始化代码
	g_pMainWnd = this;

	this->SetWindowText(L"LMI系列相机采集程序");
	//this->SetWindowText(L"Keyence系列相机采集程序");
	this->WriteLog(L"系统运行");

	//图片显示框标题显示
	font.CreatePointFont(200, _T("宋体"));
	GetDlgItem(IDC_TXT_HEIGHT)->SetFont(&font);
	GetDlgItem(IDC_TXT_INTENS)->SetFont(&font);
	GetDlgItem(IDC_TXT_DJ)->SetFont(&font);
	GetDlgItem(IDC_TXT_QX)->SetFont(&font);

	GetDlgItem(IDC_TXT_HEIGHT)->SetWindowText(L"高度图");
	GetDlgItem(IDC_TXT_INTENS)->SetWindowText(L"亮度图");
	GetDlgItem(IDC_TXT_DJ)->SetWindowText(L"倒角处理结果");
	GetDlgItem(IDC_TXT_QX)->SetWindowText(L"缺陷处理结果");

	//初始化运行缓存区满定时器
	SetTimer(BufferFullID, BUFFER_FULL_TIMER_INTERVAL, NULL);

	//初始化int型的收集亮度信息
	ProfileCountNum = _ttoi(ProfileCount);

	// 默认更新一次存图位置，默认为0，初始化的时候自加1
	ChangeSaveFileName();
	SaveFilePath = SaveImgPath;
	//WriteLog(L"当前选择的存图位置为：" + SaveFilePath);
	GetDlgItem(IDC_STA_ADDPATH)->SetWindowTextW(SaveFilePath);

	//SetTimer(5,1000,NULL);

	// 默认为暂停的文字
	GetDlgItem(IDC_BTN_PAUSECAM)->SetWindowText(L"暂停");

	//默认选择保存文件
	((CButton *)GetDlgItem(IDC_CHK_CHOOSESAVEIMG))->SetCheck(TRUE);
	((CButton *)GetDlgItem(IDC_CHK_ISSETPBYMORE))->SetCheck(TRUE);

	// 默认选择非PLC采集	
	((CButton*)GetDlgItem(IDC_RAD_NOTPLC))->SetCheck(BST_CHECKED);

	// 默认选择固定数量采集
	((CButton*)GetDlgItem(IDC_CHK_ISSAVEFROMNUM))->SetCheck(BST_CHECKED);

	SaveImgCount = SaveImgNumCount;
	CString str;
	str.Format(_T("%d"), SaveImgCount);
	GetDlgItem(IDC_STA_SAVENUM)->SetWindowTextW(str);
	

	return TRUE;  // 除非将焦点设置到控件，否则返回 TRUE
}

void CLJX800AControlDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// 如果向对话框添加最小化按钮，则需要下面的代码
//  来绘制该图标。  对于使用文档/视图模型的 MFC 应用程序，
//  这将由框架自动完成。

void CLJX800AControlDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // 用于绘制的设备上下文

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// 使图标在工作区矩形中居中
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// 绘制图标
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

//当用户拖动最小化窗口时系统调用此函数取得光标
//显示。
HCURSOR CLJX800AControlDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

// 更新数据接收变量的值
CString CLJX800AControlDlg::UpDateReceiveCount()
{
	CString strProfCountTemp;

	for (int i = 0; i < LJX8IF_GUI_DEVICE_COUNT; i++)
	{
		strProfCountTemp.Format(_T("%d"), m_anProfReceiveCount[i]);
	}

	return strProfCountTemp;
}

//具体执行显示图片的函数
void CLJX800AControlDlg::displaySend(int t, HalconCpp::HObject img)
{
	std::shared_ptr<HObject> ho_img_ptr = std::make_shared<HObject>(img);
	
	OnDrawShowInfoSize(t, ho_img_ptr);
	
	//显示句柄用完之后要记得及时销毁
	//销毁句柄的方式测试
	
	//HDevWindowStack::Pop();
	//HalconCpp::CloseWindow(HDevWindowStack::Pop());
}

// Chapter: Graphics / Text
// Short Description: Set font independent of OS 
//设置在图片上显示文字的大小颜色
void CLJX800AControlDlg::set_display_font(HTuple hv_WindowHandle, HTuple hv_Size, HTuple hv_Font, HTuple hv_Bold,
	HTuple hv_Slant)
{
	//// Local iconic variables

	//// Local control variables

	HTuple  hv_OS, hv_BufferWindowHandle, hv_Ascent;
	HTuple  hv_Descent, hv_Width, hv_Height, hv_Scale, hv_Exception;
	HTuple  hv_SubFamily, hv_Fonts, hv_SystemFonts, hv_Guess;
	HTuple  hv_I, hv_Index, hv_AllowedFontSizes, hv_Distances;
	HTuple  hv_Indices, hv_FontSelRegexp, hv_FontsCourier;

	//This procedure sets the text font of the current window with
	//the specified attributes.
	//It is assumed that following fonts are installed on the system:
	//Windows: Courier New, Arial Times New Roman
	//Mac OS X: CourierNewPS, Arial, TimesNewRomanPS
	//Linux: courier, helvetica, times
	//Because fonts are displayed smaller on Linux than on Windows,
	//a scaling factor of 1.25 is used the get comparable results.
	//For Linux, only a limited number of font sizes is supported,
	//to get comparable results, it is recommended to use one of the
	//following sizes: 9, 11, 14, 16, 20, 27
	//(which will be mapped internally on Linux systems to 11, 14, 17, 20, 25, 34)
	//
	//Input parameters:
	//WindowHandle: The graphics window for which the font will be set
	//Size: The font size. If Size=-1, the default of 16 is used.
	//Bold: If set to 'true', a bold font is used
	//Slant: If set to 'true', a slanted font is used
	//
	GetSystem("operating_system", &hv_OS);
	// dev_get_preferences(...); only in hdevelop
	// dev_set_preferences(...); only in hdevelop
	if (0 != (HTuple(hv_Size == HTuple()).TupleOr(hv_Size == -1)))
	{
		hv_Size = 16;
	}
	if (0 != ((hv_OS.TupleSubstr(0, 2)) == HTuple("Win")))
	{
		//Set font on Windows systems
		try
		{
			//Check, if font scaling is switched on
			OpenWindow(0, 0, 256, 256, 0, "buffer", "", &hv_BufferWindowHandle);
			HalconCpp::SetFont(hv_BufferWindowHandle, "-Consolas-16-*-0-*-*-1-");
			GetStringExtents(hv_BufferWindowHandle, "test_string", &hv_Ascent, &hv_Descent,
				&hv_Width, &hv_Height);
			//Expected width is 110
			hv_Scale = 110.0 / hv_Width;
			hv_Size = (hv_Size * hv_Scale).TupleInt();
			HalconCpp::CloseWindow(hv_BufferWindowHandle);
		}
		// catch (Exception) 
		catch (HalconCpp::HException& HDevExpDefaultException)
		{
			HDevExpDefaultException.ToHTuple(&hv_Exception);
			//throw (Exception)
		}
		if (0 != (HTuple(hv_Font == HTuple("Courier")).TupleOr(hv_Font == HTuple("courier"))))
		{
			hv_Font = "Courier New";
		}
		else if (0 != (hv_Font == HTuple("mono")))
		{
			hv_Font = "Consolas";
		}
		else if (0 != (hv_Font == HTuple("sans")))
		{
			hv_Font = "Arial";
		}
		else if (0 != (hv_Font == HTuple("serif")))
		{
			hv_Font = "Times New Roman";
		}
		if (0 != (hv_Bold == HTuple("true")))
		{
			hv_Bold = 1;
		}
		else if (0 != (hv_Bold == HTuple("false")))
		{
			hv_Bold = 0;
		}
		else
		{
			hv_Exception = "Wrong value of control parameter Bold";
			throw HalconCpp::HException(hv_Exception);
		}
		if (0 != (hv_Slant == HTuple("true")))
		{
			hv_Slant = 1;
		}
		else if (0 != (hv_Slant == HTuple("false")))
		{
			hv_Slant = 0;
		}
		else
		{
			hv_Exception = "Wrong value of control parameter Slant";
			throw HalconCpp::HException(hv_Exception);
		}
		try
		{
			HalconCpp::SetFont(hv_WindowHandle, ((((((("-" + hv_Font) + "-") + hv_Size) + "-*-") + hv_Slant) + "-*-*-") + hv_Bold) + "-");
		}
		// catch (Exception) 
		catch (HalconCpp::HException& HDevExpDefaultException)
		{
			HDevExpDefaultException.ToHTuple(&hv_Exception);
			//throw (Exception)
		}
	}
	else if (0 != ((hv_OS.TupleSubstr(0, 2)) == HTuple("Dar")))
	{
		//Set font on Mac OS X systems. Since OS X does not have a strict naming
		//scheme for font attributes, we use tables to determine the correct font
		//name.
		hv_SubFamily = 0;
		if (0 != (hv_Slant == HTuple("true")))
		{
			hv_SubFamily = hv_SubFamily | 1;
		}
		else if (0 != (hv_Slant != HTuple("false")))
		{
			hv_Exception = "Wrong value of control parameter Slant";
			throw HalconCpp::HException(hv_Exception);
		}
		if (0 != (hv_Bold == HTuple("true")))
		{
			hv_SubFamily = hv_SubFamily | 2;
		}
		else if (0 != (hv_Bold != HTuple("false")))
		{
			hv_Exception = "Wrong value of control parameter Bold";
			throw HalconCpp::HException(hv_Exception);
		}
		if (0 != (hv_Font == HTuple("mono")))
		{
			hv_Fonts.Clear();
			hv_Fonts[0] = "Menlo-Regular";
			hv_Fonts[1] = "Menlo-Italic";
			hv_Fonts[2] = "Menlo-Bold";
			hv_Fonts[3] = "Menlo-BoldItalic";
		}
		else if (0 != (HTuple(hv_Font == HTuple("Courier")).TupleOr(hv_Font == HTuple("courier"))))
		{
			hv_Fonts.Clear();
			hv_Fonts[0] = "CourierNewPSMT";
			hv_Fonts[1] = "CourierNewPS-ItalicMT";
			hv_Fonts[2] = "CourierNewPS-BoldMT";
			hv_Fonts[3] = "CourierNewPS-BoldItalicMT";
		}
		else if (0 != (hv_Font == HTuple("sans")))
		{
			hv_Fonts.Clear();
			hv_Fonts[0] = "ArialMT";
			hv_Fonts[1] = "Arial-ItalicMT";
			hv_Fonts[2] = "Arial-BoldMT";
			hv_Fonts[3] = "Arial-BoldItalicMT";
		}
		else if (0 != (hv_Font == HTuple("serif")))
		{
			hv_Fonts.Clear();
			hv_Fonts[0] = "TimesNewRomanPSMT";
			hv_Fonts[1] = "TimesNewRomanPS-ItalicMT";
			hv_Fonts[2] = "TimesNewRomanPS-BoldMT";
			hv_Fonts[3] = "TimesNewRomanPS-BoldItalicMT";
		}
		else
		{
			//Attempt to figure out which of the fonts installed on the system
			//the user could have meant.
			QueryFont(hv_WindowHandle, &hv_SystemFonts);
			hv_Fonts.Clear();
			hv_Fonts.Append(hv_Font);
			hv_Fonts.Append(hv_Font);
			hv_Fonts.Append(hv_Font);
			hv_Fonts.Append(hv_Font);
			hv_Guess.Clear();
			hv_Guess.Append(hv_Font);
			hv_Guess.Append(hv_Font + "-Regular");
			hv_Guess.Append(hv_Font + "MT");
			{
				HTuple end_val100 = (hv_Guess.TupleLength()) - 1;
				HTuple step_val100 = 1;
				for (hv_I = 0; hv_I.Continue(end_val100, step_val100); hv_I += step_val100)
				{
					TupleFind(hv_SystemFonts, HTuple(hv_Guess[hv_I]), &hv_Index);
					if (0 != (hv_Index != -1))
					{
						hv_Fonts[0] = HTuple(hv_Guess[hv_I]);
						break;
					}
				}
			}
			//Guess name of slanted font
			hv_Guess.Clear();
			hv_Guess.Append(hv_Font + "-Italic");
			hv_Guess.Append(hv_Font + "-ItalicMT");
			hv_Guess.Append(hv_Font + "-Oblique");
			{
				HTuple end_val109 = (hv_Guess.TupleLength()) - 1;
				HTuple step_val109 = 1;
				for (hv_I = 0; hv_I.Continue(end_val109, step_val109); hv_I += step_val109)
				{
					TupleFind(hv_SystemFonts, HTuple(hv_Guess[hv_I]), &hv_Index);
					if (0 != (hv_Index != -1))
					{
						hv_Fonts[1] = HTuple(hv_Guess[hv_I]);
						break;
					}
				}
			}
			//Guess name of bold font
			hv_Guess.Clear();
			hv_Guess.Append(hv_Font + "-Bold");
			hv_Guess.Append(hv_Font + "-BoldMT");
			{
				HTuple end_val118 = (hv_Guess.TupleLength()) - 1;
				HTuple step_val118 = 1;
				for (hv_I = 0; hv_I.Continue(end_val118, step_val118); hv_I += step_val118)
				{
					TupleFind(hv_SystemFonts, HTuple(hv_Guess[hv_I]), &hv_Index);
					if (0 != (hv_Index != -1))
					{
						hv_Fonts[2] = HTuple(hv_Guess[hv_I]);
						break;
					}
				}
			}
			//Guess name of bold slanted font
			hv_Guess.Clear();
			hv_Guess.Append(hv_Font + "-BoldItalic");
			hv_Guess.Append(hv_Font + "-BoldItalicMT");
			hv_Guess.Append(hv_Font + "-BoldOblique");
			{
				HTuple end_val127 = (hv_Guess.TupleLength()) - 1;
				HTuple step_val127 = 1;
				for (hv_I = 0; hv_I.Continue(end_val127, step_val127); hv_I += step_val127)
				{
					TupleFind(hv_SystemFonts, HTuple(hv_Guess[hv_I]), &hv_Index);
					if (0 != (hv_Index != -1))
					{
						hv_Fonts[3] = HTuple(hv_Guess[hv_I]);
						break;
					}
				}
			}
		}
		hv_Font = ((const HTuple&)hv_Fonts)[hv_SubFamily];
		try
		{
			HalconCpp::SetFont(hv_WindowHandle, (hv_Font + "-") + hv_Size);
		}
		// catch (Exception) 
		catch (HalconCpp::HException& HDevExpDefaultException)
		{
			HDevExpDefaultException.ToHTuple(&hv_Exception);
			//throw (Exception)
		}
	}
	else
	{
		//Set font for UNIX systems
		hv_Size = hv_Size * 1.25;
		hv_AllowedFontSizes.Clear();
		hv_AllowedFontSizes[0] = 11;
		hv_AllowedFontSizes[1] = 14;
		hv_AllowedFontSizes[2] = 17;
		hv_AllowedFontSizes[3] = 20;
		hv_AllowedFontSizes[4] = 25;
		hv_AllowedFontSizes[5] = 34;
		if (0 != ((hv_AllowedFontSizes.TupleFind(hv_Size)) == -1))
		{
			hv_Distances = (hv_AllowedFontSizes - hv_Size).TupleAbs();
			TupleSortIndex(hv_Distances, &hv_Indices);
			hv_Size = ((const HTuple&)hv_AllowedFontSizes)[HTuple(hv_Indices[0])];
		}
		if (0 != (HTuple(hv_Font == HTuple("mono")).TupleOr(hv_Font == HTuple("Courier"))))
		{
			hv_Font = "courier";
		}
		else if (0 != (hv_Font == HTuple("sans")))
		{
			hv_Font = "helvetica";
		}
		else if (0 != (hv_Font == HTuple("serif")))
		{
			hv_Font = "times";
		}
		if (0 != (hv_Bold == HTuple("true")))
		{
			hv_Bold = "bold";
		}
		else if (0 != (hv_Bold == HTuple("false")))
		{
			hv_Bold = "medium";
		}
		else
		{
			hv_Exception = "Wrong value of control parameter Bold";
			throw HalconCpp::HException(hv_Exception);
		}
		if (0 != (hv_Slant == HTuple("true")))
		{
			if (0 != (hv_Font == HTuple("times")))
			{
				hv_Slant = "i";
			}
			else
			{
				hv_Slant = "o";
			}
		}
		else if (0 != (hv_Slant == HTuple("false")))
		{
			hv_Slant = "r";
		}
		else
		{
			hv_Exception = "Wrong value of control parameter Slant";
			throw HalconCpp::HException(hv_Exception);
		}
		try
		{
			HalconCpp::SetFont(hv_WindowHandle, ((((((("-adobe-" + hv_Font) + "-") + hv_Bold) + "-") + hv_Slant) + "-normal-*-") + hv_Size) + "-*-*-*-*-*-*-*");
		}
		// catch (Exception) 
		catch (HalconCpp::HException& HDevExpDefaultException)
		{
			HDevExpDefaultException.ToHTuple(&hv_Exception);
			if (0 != (HTuple((hv_OS.TupleSubstr(0, 4)) == HTuple("Linux")).TupleAnd(hv_Font == HTuple("courier"))))
			{
				QueryFont(hv_WindowHandle, &hv_Fonts);
				hv_FontSelRegexp = (("^-[^-]*-[^-]*[Cc]ourier[^-]*-" + hv_Bold) + "-") + hv_Slant;
				hv_FontsCourier = (hv_Fonts.TupleRegexpSelect(hv_FontSelRegexp)).TupleRegexpMatch(hv_FontSelRegexp);
				if (0 != ((hv_FontsCourier.TupleLength()) == 0))
				{
					hv_Exception = "Wrong font name";
					//throw (Exception)
				}
				else
				{
					try
					{
						HalconCpp::SetFont(hv_WindowHandle, ((HTuple(hv_FontsCourier[0]) + "-normal-*-") + hv_Size) + "-*-*-*-*-*-*-*");
					}
					// catch (Exception) 
					catch (HalconCpp::HException& HDevExpDefaultException)
					{
						HDevExpDefaultException.ToHTuple(&hv_Exception);
						//throw (Exception)
					}
				}
			}
			//throw (Exception)
		}
	}
	// dev_set_preferences(...); only in hdevelop
	return;

}

// Chapter: Graphics / Text
// Short Description: This procedure writes a text message. 
//设置在图片上显示文字
void CLJX800AControlDlg::disp_message(HTuple hv_WindowHandle, HTuple hv_String, HTuple hv_CoordSystem,
	HTuple hv_Row, HTuple hv_Column, HTuple hv_Color, HTuple hv_Box)
{

	// Local iconic variables

	// Local control variables
	HTuple  hv_Red, hv_Green, hv_Blue, hv_Row1Part;
	HTuple  hv_Column1Part, hv_Row2Part, hv_Column2Part, hv_RowWin;
	HTuple  hv_ColumnWin, hv_WidthWin, hv_HeightWin, hv_MaxAscent;
	HTuple  hv_MaxDescent, hv_MaxWidth, hv_MaxHeight, hv_R1;
	HTuple  hv_C1, hv_FactorRow, hv_FactorColumn, hv_UseShadow;
	HTuple  hv_ShadowColor, hv_Exception, hv_Width, hv_Index;
	HTuple  hv_Ascent, hv_Descent, hv_W, hv_H, hv_FrameHeight;
	HTuple  hv_FrameWidth, hv_R2, hv_C2, hv_DrawMode, hv_CurrentColor;

	//This procedure displays text in a graphics window.
	//
	//Input parameters:
	//WindowHandle: The WindowHandle of the graphics window, where
	//   the message should be displayed
	//String: A tuple of strings containing the text message to be displayed
	//CoordSystem: If set to 'window', the text position is given
	//   with respect to the window coordinate system.
	//   If set to 'image', image coordinates are used.
	//   (This may be useful in zoomed images.)
	//Row: The row coordinate of the desired text position
	//   If set to -1, a default value of 12 is used.
	//Column: The column coordinate of the desired text position
	//   If set to -1, a default value of 12 is used.
	//Color: defines the color of the text as string.
	//   If set to [], '' or 'auto' the currently set color is used.
	//   If a tuple of strings is passed, the colors are used cyclically
	//   for each new textline.
	//Box: If Box[0] is set to 'true', the text is written within an orange box.
	//     If set to' false', no box is displayed.
	//     If set to a color string (e.g. 'white', '#FF00CC', etc.),
	//       the text is written in a box of that color.
	//     An optional second value for Box (Box[1]) controls if a shadow is displayed:
	//       'true' -> display a shadow in a default color
	//       'false' -> display no shadow (same as if no second value is given)
	//       otherwise -> use given string as color string for the shadow color
	//
	//Prepare window
	GetRgb(hv_WindowHandle, &hv_Red, &hv_Green, &hv_Blue);
	GetPart(hv_WindowHandle, &hv_Row1Part, &hv_Column1Part, &hv_Row2Part, &hv_Column2Part);
	GetWindowExtents(hv_WindowHandle, &hv_RowWin, &hv_ColumnWin, &hv_WidthWin, &hv_HeightWin);
	SetPart(hv_WindowHandle, 0, 0, hv_HeightWin - 1, hv_WidthWin - 1);
	//
	//default settings
	if (0 != (hv_Row == -1))
	{
		hv_Row = 12;
	}
	if (0 != (hv_Column == -1))
	{
		hv_Column = 12;
	}
	if (0 != (hv_Color == HTuple()))
	{
		hv_Color = "";
	}
	//
	hv_String = (("" + hv_String) + "").TupleSplit("\n");
	//
	//Estimate extentions of text depending on font size.
	GetFontExtents(hv_WindowHandle, &hv_MaxAscent, &hv_MaxDescent, &hv_MaxWidth, &hv_MaxHeight);
	if (0 != (hv_CoordSystem == HTuple("window")))
	{
		hv_R1 = hv_Row;
		hv_C1 = hv_Column;
	}
	else
	{
		//Transform image to window coordinates
		hv_FactorRow = (1. * hv_HeightWin) / ((hv_Row2Part - hv_Row1Part) + 1);
		hv_FactorColumn = (1. * hv_WidthWin) / ((hv_Column2Part - hv_Column1Part) + 1);
		hv_R1 = ((hv_Row - hv_Row1Part) + 0.5) * hv_FactorRow;
		hv_C1 = ((hv_Column - hv_Column1Part) + 0.5) * hv_FactorColumn;
	}
	//
	//Display text box depending on text size
	hv_UseShadow = 1;
	hv_ShadowColor = "gray";
	if (0 != (HTuple(hv_Box[0]) == HTuple("true")))
	{
		hv_Box[0] = "#fce9d4";
		hv_ShadowColor = "#f28d26";
	}
	if (0 != ((hv_Box.TupleLength()) > 1))
	{
		if (0 != (HTuple(hv_Box[1]) == HTuple("true")))
		{
			//Use default ShadowColor set above
		}
		else if (0 != (HTuple(hv_Box[1]) == HTuple("false")))
		{
			hv_UseShadow = 0;
		}
		else
		{
			hv_ShadowColor = ((const HTuple&)hv_Box)[1];
			//Valid color?
			try
			{
				SetColor(hv_WindowHandle, HTuple(hv_Box[1]));
			}
			// catch (Exception) 
			catch (HalconCpp::HException& HDevExpDefaultException)
			{
				HDevExpDefaultException.ToHTuple(&hv_Exception);
				hv_Exception = "Wrong value of control parameter Box[1] (must be a 'true', 'false', or a valid color string)";
				throw HalconCpp::HException(hv_Exception);
			}
		}
	}
	if (0 != (HTuple(hv_Box[0]) != HTuple("false")))
	{
		//Valid color?
		try
		{
			SetColor(hv_WindowHandle, HTuple(hv_Box[0]));
		}
		// catch (Exception) 
		catch (HalconCpp::HException& HDevExpDefaultException)
		{
			HDevExpDefaultException.ToHTuple(&hv_Exception);
			hv_Exception = "Wrong value of control parameter Box[0] (must be a 'true', 'false', or a valid color string)";
			throw HalconCpp::HException(hv_Exception);
		}
		//Calculate box extents
		hv_String = (" " + hv_String) + " ";
		hv_Width = HTuple();
		{
			HTuple end_val93 = (hv_String.TupleLength()) - 1;
			HTuple step_val93 = 1;
			for (hv_Index = 0; hv_Index.Continue(end_val93, step_val93); hv_Index += step_val93)
			{
				GetStringExtents(hv_WindowHandle, HTuple(hv_String[hv_Index]), &hv_Ascent,
					&hv_Descent, &hv_W, &hv_H);
				hv_Width = hv_Width.TupleConcat(hv_W);
			}
		}
		hv_FrameHeight = hv_MaxHeight * (hv_String.TupleLength());
		hv_FrameWidth = (HTuple(0).TupleConcat(hv_Width)).TupleMax();
		hv_R2 = hv_R1 + hv_FrameHeight;
		hv_C2 = hv_C1 + hv_FrameWidth;
		//Display rectangles
		GetDraw(hv_WindowHandle, &hv_DrawMode);
		SetDraw(hv_WindowHandle, "fill");
		//Set shadow color
		SetColor(hv_WindowHandle, hv_ShadowColor);
		if (0 != hv_UseShadow)
		{
			DispRectangle1(hv_WindowHandle, hv_R1 + 1, hv_C1 + 1, hv_R2 + 1, hv_C2 + 1);
		}
		//Set box color
		SetColor(hv_WindowHandle, HTuple(hv_Box[0]));
		DispRectangle1(hv_WindowHandle, hv_R1, hv_C1, hv_R2, hv_C2);
		SetDraw(hv_WindowHandle, hv_DrawMode);
	}
	//Write text.
	{
		HTuple end_val115 = (hv_String.TupleLength()) - 1;
		HTuple step_val115 = 1;
		for (hv_Index = 0; hv_Index.Continue(end_val115, step_val115); hv_Index += step_val115)
		{
			hv_CurrentColor = ((const HTuple&)hv_Color)[hv_Index % (hv_Color.TupleLength())];
			if (0 != (HTuple(hv_CurrentColor != HTuple("")).TupleAnd(hv_CurrentColor != HTuple("auto"))))
			{
				SetColor(hv_WindowHandle, hv_CurrentColor);
			}
			else
			{
				SetRgb(hv_WindowHandle, hv_Red, hv_Green, hv_Blue);
			}
			hv_Row = hv_R1 + (hv_MaxHeight * hv_Index);
			SetTposition(hv_WindowHandle, hv_Row, hv_C1);
			WriteString(hv_WindowHandle, HTuple(hv_String[hv_Index]));
		}
	}
	//Reset changed window settings
	SetRgb(hv_WindowHandle, hv_Red, hv_Green, hv_Blue);
	SetPart(hv_WindowHandle, hv_Row1Part, hv_Column1Part, hv_Row2Part, hv_Column2Part);
	return;
}

//显示倒角尺寸到图片位置
void CLJX800AControlDlg::displayImgInfo(int t, HTuple ChamPhi_L, HTuple ChamPhi_R,
											HTuple ChamWidthL, HTuple ChamWidthR,HTuple PelletLength,HTuple CircDefPercent)
{
	if (t == 3)
	{
		set_display_font(hv_windowhandle3, 12, "sans", "true", "false");
		disp_message(hv_windowhandle3, L"左倒角角度:" + ChamPhi_L + "\r\n" +
										L"右倒角角度:" + ChamPhi_R + "\r\n" +
										L"左倒角宽度:" + ChamWidthL + "\r\n" +
										L"右倒角宽度:" + ChamWidthR + "\r\n" +
										L"样品长度:" + PelletLength + "\r\n" ,
			"window", 12, 12, "black", "true");
	}
	else if (t == 4)
	{
		set_display_font(hv_windowhandle4, 12, "sans", "true", "false");
		disp_message(hv_windowhandle4, L"缺陷占比:" + CircDefPercent ,
			"window", 12, 12, "black", "true");
	}
}

//重绘计算面积 1为高度图  2为亮度图  3为倒角  4为缺陷
void CLJX800AControlDlg::OnDrawShowInfoSize(int t, std::shared_ptr<HalconCpp::HObject> img)
{
	double xScale;
	double yScale;
	double scale;
	double bmpShowWidth;
	double bmpShowHeight;
	double xWndStart;
	double yWndStart;
	HalconCpp::HTuple	Img_Width, Img_Height;
	CRect rc;

	try
	{
		HalconCpp::GetImageSize(*img, &Img_Width, &Img_Height);

		switch (t)
		{
		case 1:
			::GetClientRect(GetDlgItem(IDC_STA_SHOWHEIGHT)->m_hWnd, rc);
			break;
		case 2:
			::GetClientRect(GetDlgItem(IDC_STA_SHOWINTENS)->m_hWnd, rc);
			break;
		case 3:
			::GetClientRect(GetDlgItem(IDC_STA_SHOWDEALDJ)->m_hWnd, rc);
			break;
		case 4:
			::GetClientRect(GetDlgItem(IDC_STA_SHOWDEALQX)->m_hWnd, rc);
			break;
		default:
			break;
		}

		xScale = (double)rc.Width() / (double)Img_Width;
		yScale = (double)rc.Height() / (double)Img_Height;
		scale = std::min<double>(xScale, yScale);
		bmpShowWidth = (double)Img_Width * scale;
		bmpShowHeight = (double)Img_Height * scale;
		xWndStart = ((double)rc.Width() - bmpShowWidth) / (double)2;
		yWndStart = ((double)rc.Height() - bmpShowHeight) / (double)2;

		// 计算等比缩放的位置和尺寸
		CWnd::Invalidate();
		CWnd::UpdateWindow();

		//yWndStart, xWndStart, bmpShowWidth, bmpShowHeight,

		switch (t)
		{
		case 1:
			HalconCpp::OpenWindow(0, 0, rc.Width(), rc.Height(),
				(Hlong)GetDlgItem(IDC_STA_SHOWHEIGHT)->m_hWnd, "visible", "", &hv_windowhandle1);
			HalconCpp::SetPart(hv_windowhandle1, 1, 1, Img_Height, Img_Width);
			HalconCpp::SetColor(hv_windowhandle1, "red");
			break;
		case 2:
			HalconCpp::OpenWindow(0, 0, rc.Width(), rc.Height(),
				(Hlong)GetDlgItem(IDC_STA_SHOWINTENS)->m_hWnd, "visible", "", &hv_windowhandle2);
			HalconCpp::SetPart(hv_windowhandle2, 1, 1, Img_Height, Img_Width);
			HalconCpp::SetColor(hv_windowhandle2, "red");
			break;
		case 3:
			HalconCpp::OpenWindow(0, 0, rc.Width(), rc.Height(),
			(Hlong)GetDlgItem(IDC_STA_SHOWDEALDJ)->m_hWnd, "visible", "", &hv_windowhandle3);
			HalconCpp::SetPart(hv_windowhandle3, 1, 1, Img_Height, Img_Width);
			HalconCpp::SetColor(hv_windowhandle3, "red");
			break;
		case 4:
			HalconCpp::OpenWindow(0, 0, rc.Width(), rc.Height(),
				(Hlong)GetDlgItem(IDC_STA_SHOWDEALQX)->m_hWnd, "visible", "", &hv_windowhandle4);
			HalconCpp::SetPart(hv_windowhandle4, 1, 1, Img_Height, Img_Width);
			HalconCpp::SetColor(hv_windowhandle4, "red");
			break;
		default:
			break;
		}

		//HalconCpp::DispObj(*img, hv_windowhandle); //显示图片的具体操作
	}
	catch (HalconCpp::HException& HDevExpDefaultException)
	{
		printf(HDevExpDefaultException.ErrorMessage());
	}
}

// 中转调用HalconCpp::DispObj函数
void CLJX800AControlDlg::ShowImg(int t, HalconCpp::HObject *img)
{
	//std::shared_ptr<HObject> hoImgPtr = std::make_shared<HObject>(img);


	switch (t)
	{
	case 3:
		HalconCpp::DispObj(*img, hv_windowhandle3);
		break;
	case 4:
		HalconCpp::DispObj(*img, hv_windowhandle4);
		break;
	default:
		break;
	}
	
	//HalconCpp::DispObj(ho_ImageOut1, hv_windowhandle3);
}

// 非阻塞延时, 单位毫秒
void CLJX800AControlDlg::XSleep(int nWaitInMsecs)
{
	XSleep_Structure sleep;
	sleep.duration = nWaitInMsecs;
	sleep.evenHandle = ::CreateEventW(NULL, TRUE, FALSE, NULL);

	/*DWORD dwThreadId;
	CreateThread(NULL, 0, &XSleepThread, &sleep, 0, &dwThreadId);*/

	HANDLE getHandle;
	getHandle = (HANDLE)_beginthreadex(NULL, 0,
		(unsigned int(__stdcall*)(void *))XSleepThread, &sleep, 0, NULL);

	MSG msg;
	while (::WaitForSingleObject(sleep.evenHandle, 0) == WAIT_TIMEOUT)
	{
		// get and dispatch message
		if (::PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
		{
			::TranslateMessage(&msg);
			::DispatchMessage(&msg);
		}
	}
	CloseHandle(sleep.evenHandle);
	CloseHandle(getHandle);
}

//日志输出
void CLJX800AControlDlg::WriteLog(CString s)
{
	auto now = std::chrono::system_clock::now();
	auto ms = std::chrono::duration_cast<std::chrono::microseconds>(now.time_since_epoch());

	CStringW str;
	//tmp.Format(L"%03d ", ms % 1000);
	//str.Insert(0, tmp);
	str.Insert(0, CTime::GetCurrentTime().Format(L"> %Y-%m-%d %H:%M:%S: "));
	str.Append(s);
	//str.Format(_T("\r\n"));
	//str += "\r\n";
	//str.Insert(str.GetLength(), L"\r\n");
	str.Append(L"\r\n");

	CEdit* pEdit = (CEdit*)GetDlgItem(IDC_LOGSHOW_EDIT);
	int len = pEdit->GetWindowTextLength();
	if (len >= static_cast<int>(pEdit->GetLimitText()))
		pEdit->SetSel(0, -1);
	else
		pEdit->SetSel(-1, -1);
	pEdit->ReplaceSel(str);

	//GetDlgItem(IDC_SHOW_INFO)->SetWindowTextW(str);
}

// 初始化DLL功能
void CLJX800AControlDlg::InitializeDLL()
{
	lRcState = LJX8IF_Initialize();

	if (lRcState != LJX8IF_RC_OK)
	{
		WriteLog(L"初始化DLL连接失败！！");
		return;
	}

	if (lRcState == LJX8IF_RC_OK)
	{
		//WriteLog(L"初始化DLL连接——成功");

		for (int i = 0; i < LJX8IF_GUI_DEVICE_COUNT; i++)
		{
			m_aDeviceData[i].m_deviceStatus = CDeviceData::DEVICESTATUS_NO_CONNECTION;
			InitializeConnectionInfo(i);
		}
	}
}

// 初始化以太网连接地址
void CLJX800AControlDlg::InitializeConnectionInfo(int targetDeviceID)
{
	m_aDeviceData[targetDeviceID].m_ethernetConfig.abyIpAddress[0] = 192;
	m_aDeviceData[targetDeviceID].m_ethernetConfig.abyIpAddress[1] = 168;
	m_aDeviceData[targetDeviceID].m_ethernetConfig.abyIpAddress[2] = 0;
	m_aDeviceData[targetDeviceID].m_ethernetConfig.abyIpAddress[3] = 1;

	m_aDeviceData[targetDeviceID].m_ethernetConfig.wPortNo = 24691;
}

//指示更改地址框文本后更新地址变量
void CLJX800AControlDlg::OnEnChangeStaAddpath()
{
	// TODO:  如果该控件是 RICHEDIT 控件，它将不
	// 发送此通知，除非重写 CDialogEx::OnInitDialog()
	// 函数并调用 CRichEditCtrl().SetEventMask()，
	// 同时将 ENM_CHANGE 标志“或”运算到掩码中。

	// TODO:  在此添加控件通知处理程序代码
	UpdateData(TRUE);
	GetDlgItem(IDC_STA_ADDPATH)->GetWindowTextW(SaveFilePath);

	//WriteLog(L"当前选择的存图位置为：" + SaveFilePath);
}


//打开选择路径功能，返回选择的路径
CString CLJX800AControlDlg::OpenChangePathDlg()
{
	// TODO: 在此添加控件通知处理程序代码
	HWND hwnd = GetSafeHwnd();   //得到窗口句柄
	SaveFilePath = SaveImgPath;

	LPMALLOC pMalloc;
	if (::SHGetMalloc(&pMalloc) == NOERROR)	//取得IMalloc分配器接口
	{
		BROWSEINFO bi;
		TCHAR pszBuffer[MAX_PATH];
		LPITEMIDLIST pidl;
		bi.hwndOwner = hwnd;
		bi.pidlRoot = NULL;
		bi.pszDisplayName = pszBuffer;
		bi.lpszTitle = _T("选择文件夹"); //选择目录对话框的上部分的标题
									//添加新建文件夹按钮 BIF_NEWDIALOGSTYLE
		bi.ulFlags = BIF_NEWDIALOGSTYLE | BIF_RETURNONLYFSDIRS | BIF_RETURNFSANCESTORS;
		bi.lpfn = NULL;
		if ((pidl = ::SHBrowseForFolder(&bi)) != NULL)  //取得IMalloc分配器接口
		{
			if (::SHGetPathFromIDList(pidl, pszBuffer)) //获得一个文件系统路径
			{
				SaveFilePath = pszBuffer;
			}
			pMalloc->Free(pidl);	//释放内存
			SetDlgItemText(IDC_STA_ADDPATH, SaveFilePath);
			WriteLog(L"当前选择的存图位置为：" + SaveFilePath);
			UpdateData(FALSE);

			lRcState = LJX8IF_RC_OK;
		}
		else
		{
			lRcState = LJX8IF_RC_ERR_RECEIVE;
			//WriteLog(L"选择保存地址失败！！");
		}
		pMalloc->Release();	//释放接口
	}


	return SaveFilePath;
}

// 获取系统时间
CString CLJX800AControlDlg::GetSysTime()
{
	auto now = std::chrono::system_clock::now();

	time_t tt = std::chrono::system_clock::to_time_t(now);
	auto time_tm = localtime(&tt);
	char strTime[25] = { 0 };
	sprintf(strTime, "%d-%02d-%02d_%02d:%02d:%02d", time_tm->tm_year + 1900,
		time_tm->tm_mon + 1, time_tm->tm_mday, time_tm->tm_hour,
		time_tm->tm_min, time_tm->tm_sec);

	return static_cast<CString>(strTime);
}

// 向txt写文件
void CLJX800AControlDlg::SaveFile2TXT(CString filename, CString text)
{
	// 向文件写内容
	// std::ios:: in只读  out只写  app末尾写
	CString time = GetSysTime();
	time += L".txt";
	filename.Append(time);
	std::ofstream outfile(filename, std::ios::out);

	//将数据输出至out.txt文件中
	outfile << text << std::endl;

	outfile.close();
}

// 在plc台架上运行时，根据顺序逐个对应文件夹
CString CLJX800AControlDlg::LoopPLCFileName(int hv_a, CString fileName)
{
	int b = hv_a;
	int temp = b % 30;
	//GetDlgItem(IDC_STA_ADDPATH)->GetWindowTextW(fileName);

	if (temp != 0)
	{
		CString str;
		str.Format(L"\\%d", temp);
		//fileName.Append();
		fileName.Append(str);
	}
	else if (temp == 0)
		fileName.Append(L"\\30" );

	return fileName;
}

//选择保存路径功能
void CLJX800AControlDlg::ChooseSavePatSingle()
{
	UpdateData(TRUE);

	/*CFileDialog fileDlg(FALSE, _T("tiff"), SaveFilePath, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		_T("TIFF (*.tif;*.tiff)|*.tif;*.tiff|Profile (*.csv)|*.csv|Bitmap (*.bmp)|*.bmp|All Files (*.*)|*.*||"));

	if (fileDlg.DoModal() != IDOK)
	{
		lRcState = LJX8IF_RC_ERR_RECEIVE;
		WriteLog(L"选择保存地址失败！！");
		return;
	}

	SaveFilePath = fileDlg.GetPathName();

	GetDlgItem(IDC_STA_ADDPATH)->SetWindowText(SaveFilePath);

	WriteLog(L"当前选择的存图位置为：" + SaveFilePath);*/

	/*int scrollPos = m_txtCommandLog.GetFirstVisibleLine();
	UpdateData(FALSE);
	m_txtCommandLog.LineScroll(scrollPos);*/
	
	SaveFilePath = CLJX800AControlDlg::OpenChangePathDlg();

	if (SaveFilePath.IsEmpty() || lRcState != LJX8IF_RC_OK)
	{
		WriteLog(L"选择保存地址失败！！");
		return;
	}
		
	return;
}

// 文件地址自加1，初始化为0，默认开启程序时+1
CString CLJX800AControlDlg::ChangeSaveFileName()
{
	//m_SaveImgAddShow.SetWindowTextW(SaveFilePath);
	//UpdateData(TRUE);

	hv_a += 1;
	//m_SaveImgAddShow.SetWindowTextW(SaveFilePath);

	//CString fileName = L"E:\\VS-Debug\\8000A-SelfControl\\image\\";
	/*fileName = SaveImgPath;
	fileName.Append(hv_a.TupleString(".2d").S());
	fileName.Append(L".tiff");
	SaveFilePath = fileName;*/

	//SaveFilePath = SaveImgPath;
	GetDlgItem(IDC_STA_ADDPATH)->GetWindowTextW(SaveFilePath);

	return SaveFilePath;
}

/*
  获取以太网配置
  返回以太网端口配置
  @return LJX8IF_ETHERNET_CONFIG
  主要指的是IP地址和相应的端口号配置
*/
LJX8IF_ETHERNET_CONFIG CLJX800AControlDlg::GetEthernetConfig()
{
	LJX8IF_ETHERNET_CONFIG ethernetConfig;

	USES_CONVERSION;
	//DWORD ipAddress = (DWORD)T2A(SensorIpStr);
	//DWORD ipAddress = (DWORD)_ttoi((LPCTSTR)SensorIpStr);
	//DWORD ipAddress = csIP2dwIP(SensorIpStr);
	char* temp = T2A(SensorIpStr);
	DWORD ipAddress = ntohl(inet_addr(temp));

	ethernetConfig.abyIpAddress[0] = (BYTE)((ipAddress & 0xFF000000) >> 24);
	ethernetConfig.abyIpAddress[1] = (BYTE)((ipAddress & 0x00FF0000) >> 16);
	ethernetConfig.abyIpAddress[2] = (BYTE)((ipAddress & 0x0000FF00) >> 8);
	ethernetConfig.abyIpAddress[3] = (BYTE)(ipAddress & 0x000000FF);

	//ethernetConfig.wPortNo         = (WORD)m_nPortNum;
	ethernetConfig.wPortNo = (WORD)PortNum;
	ethernetConfig.reserve[0] = (BYTE)0;
	ethernetConfig.reserve[1] = (BYTE)0;

	return ethernetConfig;
}

// 打开以太网连接功能
void CLJX800AControlDlg::OpenEthernetSingle()
{
	//COpenEthernetDlg communicaionSettinDlg;
	//if (communicaionSettinDlg.DoModal() != IDOK) return;

	LJX8IF_ETHERNET_CONFIG ethernetConfig = GetEthernetConfig();
	lRcState = LJX8IF_EthernetOpen((LONG)m_nCurrentDeviceID, &ethernetConfig);

	if (lRcState != LJX8IF_RC_OK)
	{
		WriteLog(L"以太网连接失败！！");
		return;
	}

	CDeviceData::DEVICESTATUS status = (lRcState == LJX8IF_RC_OK) ? CDeviceData::DEVICESTATUS_ETHERNET : CDeviceData::DEVICESTATUS_NO_CONNECTION;
	m_aDeviceData[m_nCurrentDeviceID].m_deviceStatus = status;

	if (lRcState == LJX8IF_RC_OK)
	{
		m_aDeviceData[m_nCurrentDeviceID].m_ethernetConfig = ethernetConfig;
		//WriteLog(L"以太网连接打开——成功");
	}
}

/*
 通讯关闭事件
*/
void CLJX800AControlDlg::Communicationclose()
{
	UpdateData(TRUE);

	LONG lRc = LJX8IF_CommunicationClose((LONG)m_nCurrentDeviceID);

	m_aDeviceData[m_nCurrentDeviceID].m_deviceStatus = CDeviceData::DEVICESTATUS_NO_CONNECTION;
	InitializeConnectionInfo(m_nCurrentDeviceID);
}

// 初始化时清除所有缓冲区以提高速度
void CLJX800AControlDlg::ClearAllHighspeedBuffer(int nDeviceId)
{
	CThreadSafeBuffer* threadSafeBuf = CThreadSafeBuffer::getInstance();
	threadSafeBuf->ClearBuffer(nDeviceId);

	m_aDeviceData[nDeviceId].m_vecProfileDataHighSpeed.clear();
	m_aDeviceData[nDeviceId].m_vecProfileDataHighSpeed.shrink_to_fit();
	m_aDeviceData[nDeviceId].m_simpleArrayStoreHighSpeed.Clear();
	m_bIsBufferFull[nDeviceId] = false;
	m_bIsStopCommunicationByError[nDeviceId] = false;

	lRcState = LJX8IF_RC_OK;

	if (lRcState != LJX8IF_RC_OK)
	{
		WriteLog(L"清除数据时发生错误！");
		return;
	}
}

/**
 Callback function for simple array (receive profile data)
 @param A pointer to the buffer that stores the header data array.
 @param A pointer to the buffer that stores the profile data array.
 @param A pointer to the buffer that stores the luminance profile data array.
 @param The value indicating whether luminance data output is enable or not.
 @param The data count of one profile.
 @param The number of profile or header data stored in buffer.
 @param notify
 @param UserID
  真实回调函数，内部仅仅开启一个函数调用，方便使用this指针
*/
void CLJX800AControlDlg::ReceiveHighSpeedSimpleArray(LJX8IF_PROFILE_HEADER* pProfileHeaderArray, WORD* pHeightProfileArray, WORD* pLuminanceProfileArray, DWORD dwLuminanceEnable, DWORD dwProfileDataCount, DWORD dwCount, DWORD dwNotify, DWORD dwUser)
{
	g_pMainWnd->OnReceiveHighSpeedSimpleArray(pProfileHeaderArray, pHeightProfileArray, pLuminanceProfileArray,
		dwLuminanceEnable, dwProfileDataCount, dwCount, dwNotify, dwUser);
}

void CLJX800AControlDlg::OnReceiveHighSpeedSimpleArray(LJX8IF_PROFILE_HEADER* pProfileHeaderArray, WORD* pHeightProfileArray, WORD* pLuminanceProfileArray, DWORD dwLuminanceEnable, DWORD dwProfileDataCount, DWORD dwCount, DWORD dwNotify, DWORD dwUser)
{
	// @Point
	// Take care to only implement storing profile data in a thread save buffer in the callback function.
	// As the thread used to call the callback function is the same as the thread used to receive data,
	// the processing time of the callback function affects the speed at which data is received,
	// and may stop communication from being performed properly in some environments.
	m_bIsBufferFull[dwUser] = m_aDeviceData[dwUser].m_simpleArrayStoreHighSpeed.AddReceivedData(pHeightProfileArray, pLuminanceProfileArray, dwCount);
	m_aDeviceData[dwUser].m_simpleArrayStoreHighSpeed.AddNotify(dwNotify);

	DWORD dwCountReceive = m_aDeviceData[dwUser].m_simpleArrayStoreHighSpeed.GetCount();
	//DWORD dwNotify2 = m_aDeviceData[dwUser].m_simpleArrayStoreHighSpeed.GetNotify();
	//int   nBatchNo2 = m_aDeviceData[dwUser].m_simpleArrayStoreHighSpeed.m_nBatchNo;

	//TRACE(L"%u %u dwLuminanceEnable=%u dwProfileDataCount=%u dwCount=%u dwNotify=%u\n",
	//	dwCount2, ::GetCurrentThreadId()
	//	, dwLuminanceEnable, dwProfileDataCount, dwCount, dwNotify
	//);


	TestRecIsEnoughAndSave(dwCountReceive, dwCount, dwNotify);
}

// 初始化以太网高速连接简单数组
void CLJX800AControlDlg::InitializehighspeeddatacommunicationSimplearray()
{
	//UpdateData(TRUE);

	//m_sendCommand = SENDCOMMAND_INITIALIZE_HIGH_SPEED_DATA_ETHERNET_COMMUNICATION;
	//CHighSpeedEthernetInitializeDlg highSpeedEthernetInitializeDlg;
	//highSpeedEthernetInitializeDlg.ethernetConfig = m_aDeviceData[m_nCurrentDeviceID].m_ethernetConfig;
	//if (highSpeedEthernetInitializeDlg.DoModal() != IDOK) return;

	// Clear the data
	ClearAllHighspeedBuffer(m_nCurrentDeviceID);

	LJX8IF_ETHERNET_CONFIG config = GetEthernetConfig();

	lRcState = LJX8IF_InitializeHighSpeedDataCommunicationSimpleArray(
		(LONG)m_nCurrentDeviceID,
		&config,
		(WORD)HeighPortNum,
		ReceiveHighSpeedSimpleArray,
		(DWORD)ProfileStartNum,
		(DWORD)m_nCurrentDeviceID);

	// @Point
	// ＃当调用频率较低时，可能无法按指定数量的配置文件调用一次回调函数。
	// ＃当同时满足以下两个条件时，将调用回调函数。
	// *有一个接收数据包。
	// *达到呼叫频率时已收到指定数量的轮廓文件。


	if (lRcState == LJX8IF_RC_OK)
	{
		m_aDeviceData[m_nCurrentDeviceID].m_deviceStatus = CDeviceData::DEVICESTATUS_ETHERNET_FAST;
		m_aDeviceData[m_nCurrentDeviceID].m_ethernetConfig = config;
		//WriteLog(L"以太网高速连接（简单数组）——成功");
	}
	else
	{
		WriteLog(L"以太网高速连接（简单数组）失败！");
		return;
	}

	//SetDlgItemText(m_sttConnectionStatus[m_nCurrentDeviceID].GetDlgCtrlID(), m_aDeviceData[m_nCurrentDeviceID].GetStatusString());
	m_anProfReceiveCount[m_nCurrentDeviceID] = 0;

	//有疑问，不知道到最后放在一个定时器里检测读取的值，还是每个可能产生的位置都要更新
	//UpDateReceiveCount();
}

// CPreStartHighSpeedDlg Message handler
/*
 Get PreStart HighSpeed Communication Request
 @return LJX8IF_HIGH_SPEED_PRE_START_REQ
 作用仅是获取轮廓的启示位置，直接设置值即可
*/
LJX8IF_HIGH_SPEED_PRE_START_REQ CLJX800AControlDlg::getHighSpeedPreStartReq()
{
	/*LJX8IF_HIGH_SPEED_PRE_START_REQ req;
	req.bySendPosition = m_bySendPos;*/

	LJX8IF_HIGH_SPEED_PRE_START_REQ req;
	req.bySendPosition = SendPosNum;

	return req;
}

// 准备启动以太网高速连接
void CLJX800AControlDlg::Prestarthighspeeddatacommunication()
{
	//UpdateData(TRUE);
	//m_sendCommand = SENDCOMMAND_PRE_START_HIGH_SPEED_DATA_COMMUNICATION;

	LJX8IF_HIGH_SPEED_PRE_START_REQ request = getHighSpeedPreStartReq();

	// @Point
	//＃SendPos用于指定在高速通信期间从哪个配置文件开始发送数据。
	//＃当内存已满且
	//将“ 0：从上一个发送完成位置开始”指定为发送开始位置，
	//如果LJ-X继续累积配置文件，则LJ-X内存将变满，
	//，并且先前发送完成位置的配置文件将被新的配置文件覆盖。
	//在这种情况下，由于未保存先前发送完成位置的配置文件，因此将发生错误。

	LJX8IF_PROFILE_INFO profileInfo;

	lRcState = LJX8IF_PreStartHighSpeedDataCommunication((LONG)m_nCurrentDeviceID, &request, &profileInfo);
	//DisplayCommandLog(lRc, IDS_PRE_START_HIGH_SPEED_DATA_COMMUNICATION);

	if (lRcState != LJX8IF_RC_OK)
	{
		WriteLog(L"准备高速以太网连接失败！！");
		return;
	}

	//ShowProfileInfo(profileInfo);
	m_aProfileInfo[m_nCurrentDeviceID] = profileInfo;

	if (m_bIsUseSimpleArray == TRUE) {
		m_aDeviceData[m_nCurrentDeviceID].m_simpleArrayStoreHighSpeed.m_nDataWidth = profileInfo.wProfileDataCount;
		m_aDeviceData[m_nCurrentDeviceID].m_simpleArrayStoreHighSpeed.m_bIsLuminanceEnable = profileInfo.byLuminanceOutput == 1;
	}
}

/*
 开启以太网连接
*/
void CLJX800AControlDlg::Starthighspeeddatacommunication()
{
	//UpdateData(TRUE);

	//m_sendCommand = SENDCOMMAND_START_HIGH_SPEED_DATA_COMMUNICATION;

	lRcState = LJX8IF_StartHighSpeedDataCommunication((LONG)m_nCurrentDeviceID);

	//if (lRcState == LJX8IF_RC_OK)
		//WriteLog(L"启动高速以太网连接——成功");
	if (lRcState != LJX8IF_RC_OK)
	{
		WriteLog(L"启动以太网高速连接失败！！");
		return;
	}
}

/*
 开始收集亮度按钮
*/
void CLJX800AControlDlg::Startmeasure()
{
	//UpdateData(TRUE);

	//m_sendCommand = SENDCOMMAND_START_MEASURE;
	lRcState = LJX8IF_StartMeasure((LONG)m_nCurrentDeviceID);

	if (lRcState != LJX8IF_RC_OK)
	{
		WriteLog(L"启动亮度值收集失败！！");
		return;
	}

	WriteLog(L"启动亮度值收集——成功");
}

// 停止以太网连接
void CLJX800AControlDlg::Stophighspeeddatacommunication()
{
	//UpdateData(TRUE);

	lRcState = LJX8IF_StopHighSpeedDataCommunication((LONG)m_nCurrentDeviceID);


	if (lRcState != LJX8IF_RC_OK)
	{
		WriteLog(L"停止以太网初始化连接失败！！");
		return;
	}
}

// 完成以太网连接
void CLJX800AControlDlg::Finalizehighspeeddatacommunication()
{
	//UpdateData(TRUE);

	lRcState = LJX8IF_FinalizeHighSpeedDataCommunication((LONG)m_nCurrentDeviceID);

	if (lRcState != LJX8IF_RC_OK)
	{
		WriteLog(L"完成以太网连接（Finalizehighspeeddatacommunication）失败！！");
		return;
	}

	LJX8IF_ETHERNET_CONFIG config;

	switch (m_aDeviceData[m_nCurrentDeviceID].m_deviceStatus)
	{
	case CDeviceData::DEVICESTATUS_ETHERNET_FAST:
		config = m_aDeviceData[m_nCurrentDeviceID].m_ethernetConfig;
		m_aDeviceData[m_nCurrentDeviceID].m_deviceStatus = CDeviceData::DEVICESTATUS_ETHERNET;
		m_aDeviceData[m_nCurrentDeviceID].m_ethernetConfig = config;
		break;

	default:
		break;
	}
}

//停止收集亮度
void CLJX800AControlDlg::Stopmeasure()
{
	//UpdateData(TRUE);

	lRcState = LJX8IF_StopMeasure((LONG)m_nCurrentDeviceID);

	/*if (lRcState == LJX8IF_RC_OK)
		WriteLog(L"停止亮度值收集——成功");*/
	if (lRcState != LJX8IF_RC_OK)
	{
		WriteLog(L"停止亮度值收集失败！！");
		return;
	}
}

/*
  作为图片保存按钮的事件
*/
void CLJX800AControlDlg::Hispeedsaveasbitmapfile()
{
	UpdateData(TRUE);

	if (SaveFilePath.IsEmpty())
	{
		WriteLog(L"存图失败（存储文件地址为空）。");
		return;
	}

	CWaitCursor waitCursor;

	//GetPos32 const以32位的精度检索上下控件的当前位置
	DWORD startIndex = ProfileIndex;						// 限制是 2^16-1
	DWORD dataCount = (DWORD)_ttol(ProfileCount);			// 限制是 2^16-1
	CString SaveNum = hv_a.TupleString(".2d").S();

	if (m_aDeviceData[m_nCurrentDeviceID].m_simpleArrayStoreHighSpeed.SaveDataAsImages(SaveFilePath, startIndex, dataCount, SaveNum))
	{
		//WriteLog(L"存图完成。");

		CString temp = L"保存第_";
		temp.Append(SaveNum);
		temp.Append(L"_张照片完成。");
		WriteLog(temp);

		//ChangeSaveFileName();

		return;
	}

	MessageBox(_T("存图失败！！"));
}

// 根据对应文件夹创建文件夹 空表示创建成功
BOOL CLJX800AControlDlg::CreateDirByName(CString filePath) 
{
	const std::string folder = CT2A(filePath.GetString());
	std::string folder_builder;
	std::string sub;
	sub.reserve(folder.size());
	for (auto it = folder.begin(); it != folder.end(); ++it) {
		// cout << *(folder.end()-1) << endl;
		const char c = *it;
		sub.push_back(c);
		if (c == '\\' || it == folder.end() - 1) 
		{
			folder_builder.append(sub);
			if (0 != ::_access(folder_builder.c_str(), 0)) 
			{
				// 意外退出
				if (0 != ::_mkdir(folder_builder.c_str())) 
				{
					// 创建失败
					return false;
				}
			}
			sub.clear();
		}
	}
	return true;
}

// 测试保存的文件夹是否存在
BOOL CLJX800AControlDlg::TestFileIsHave(CString SaveFilePath)
{
	CString heightPath = SaveFilePath;
	CString intensPath = SaveFilePath;
	heightPath.Append(L"\\height\\");
	intensPath.Append(L"\\intens\\");

	// 返回true表示没有这个文件夹
	if (GetFileAttributes(heightPath))
	{
		// 返回true表示创建成功
		if (!CreateDirByName(heightPath))
		{
			WriteLog(L"创建高度值文件夹失败，保存失败!!!");
			lRcState = LJX8IF_RC_ERR_NOT_OPEN;
			return FALSE;
		}
		lRcState = LJX8IF_RC_OK;
	}

	if (GetFileAttributes(intensPath))
	{
		// 返回true表示创建成功
		if (!CreateDirByName(intensPath))
		{
			WriteLog(L"创建亮度值文件夹失败，保存失败!!!");
			lRcState = LJX8IF_RC_ERR_NOT_OPEN;
			return FALSE;
		}
		lRcState = LJX8IF_RC_OK;
	}

	if (lRcState != LJX8IF_RC_OK)
		return FALSE;
	else
		return TRUE;
}

// 检测样品是否跑出边界，返回true是跑出边界
BOOL CLJX800AControlDlg::TestImgIsRunOutBorder(std::shared_ptr<HObject>  ho_Image)
{

	// Local control variables
	HalconCpp::HTuple  hv_Width, hv_Height, hv_HorProjection;
	HalconCpp::HTuple  hv_VertProjection, hv_A, hv_B;


	GetImageSize(*ho_Image, &hv_Width, &hv_Height);
	GrayProjections(*ho_Image, *ho_Image, "simple", &hv_HorProjection, &hv_VertProjection);

	hv_A = (hv_VertProjection.TupleSelectRange(0, 49)).TupleSum();
	hv_B = (hv_VertProjection.TupleSelectRange(hv_Width - 50, hv_Width - 1)).TupleSum();
	if (0 != (HTuple(int(hv_A >= 5)).TupleOr(int(hv_B >= 5))))
		return true;
	
	return false;
}

// 检测是否满足收集足够的亮度值数据，在收集满的情况下存图，完成后并清理内存，等待下一次拍照
void CLJX800AControlDlg::TestRecIsEnoughAndSave(DWORD dwCountReceive, DWORD dwCount, DWORD dwNotify)
{
	if (dwCountReceive == ProfileCountNum && dwCount == 0 && dwNotify == 65536)
	{
		// 定时刷新接受到的轮廓数，到指定后自动停止测量和存储图片
		// SetTimer(SaveImgID, 1, NULL);
		// 要在主线程中杀死回调会导致崩溃，如果另开启一个线程来启动关闭就不会导致问题。
		m_ThreadPool.enqueue([this]()
		{
			ReceiveEnough = true;

			Stopmeasure();
			VecToImgSaveAndShow();

			Clear_StopMark = true;

			if (lRcState == LJX8IF_RC_OK)
			{
				
				CString str;
				GetDlgItem(IDC_STA_SAVENUM)->GetWindowTextW(str);
				int SaveImgWant = _ttoi(str) * 30;
				if (hv_a.I() == _ttoi(str) && ((CButton *)GetDlgItem(IDC_RAD_NOTPLC))->GetCheck())
					OnBnClickedBtnClosecam();
				else if (hv_a.I() == SaveImgWant && ((CButton *)GetDlgItem(IDC_RAD_PLC))->GetCheck())
				{
					OnBnClickedBtnClosecam();
					hv_a += 1;
				}
				else
					ChangeSaveFileName();

				/*if (!isMOXOnBoder)
					ChangeSaveFileName();*/
				
				try
				{
					if (isCamOpen)
					{
						//方法0
						if (LJX8IF_RC_OK != LJX8IF_ClearMemory(m_nCurrentDeviceID))
							WriteLog(L"内存清除错误");

						//方法1
						Stophighspeeddatacommunication();
						Finalizehighspeeddatacommunication();

						InitializehighspeeddatacommunicationSimplearray();
						Prestarthighspeeddatacommunication();
						Starthighspeeddatacommunication();

						if (lRcState != LJX8IF_RC_OK)
						{
							hv_b = hv_a;

							LJX8IF_Finalize();
							isCamOpen = FALSE;
							//OnBnClickedBtnOpencam();
							WriteLog(L"关闭高速通信时发生异常，如果想要重新拍摄，请打开相机");
						}

						// 默认选择多次采集
						if (!isPauseBtn && !isMOXOnBoder)
							if (BST_CHECKED == IsDlgButtonChecked(IDC_CHK_ISSETPBYMORE))
								OnBnClickedBtnStartcam();
					}

					if (!isCamOpen)
						return;
				}
				catch (const std::exception& ex)
				{
					CString str;
					str.Format(L"%s",ex.what());
					WriteLog(str);
				}
			}
		});
	}
}

// 保存拍摄后的图片数据到对应的文件
// -1表示参数错误  
// 1 表示文件已存在
// Savemark 1表示高度图  2表示亮度图
void CLJX800AControlDlg::SaveImg(int SaveInfoMark, CString SaveFilePath, int hv_a, std::shared_ptr<HalconCpp::HObject> img)
{
	CString heightPath = SaveFilePath;
	CString intensPath = SaveFilePath;
	heightPath.Append(L"\\height\\");
	intensPath.Append(L"\\intens\\");

	SYSTEMTIME st;
	CString strDate;
	GetLocalTime(&st);
	strDate.Format(L"%4d%02d%02d_%02d%02d%02d", st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond);

	/*CTime sTime = CTime::GetCurrentTime();
	CString strDateTemp;
	strDateTemp.Format(L"%4d%2d%2d_%2d%2d%2d", sTime.GetYear(), sTime.GetMonth(), sTime.GetDay()
		, sTime.GetHour(), sTime.GetMinute(), sTime.GetSecond());*/

	CString s;
	s.Format(_T("_%05d"), hv_a);

	try
	{
		switch (SaveInfoMark)
		{
		case 1:  // 1表示高度图
			//heightPath.Append(L"\\");
			heightPath.Append(strDate);
			heightPath.Append(s);
			heightPath.Append(L"_height.tiff");
			HalconCpp::WriteImage(*img, "tiff", 0, heightPath.GetBuffer());
			//WriteLog(L"保存高度图信息完成");
			lRcState = LJX8IF_RC_OK;
			break;
		case 2:	// 2表示亮度图
			//intensPath.Append(L"\\");
			intensPath.Append(strDate);
			intensPath.Append(s);
			intensPath.Append(L"_intens.tiff");
			HalconCpp::WriteImage(*img, "tiff", 0, intensPath.GetBuffer());
			//WriteLog(L"保存亮度图信息完成");
			lRcState = LJX8IF_RC_OK;
			break;
		default:
			WriteLog(L"错误的保存文件信息");
			lRcState = LJX8IF_RC_ERR_RECEIVE;
			break;
		}

		if (lRcState != LJX8IF_RC_OK)
			WriteLog(L"!!warning:存图发生异常操作！！！！！！");
	}
	catch (HalconCpp::HException& HDevExpDefaultException)
	{
		//printf(HDevExpDefaultException.ErrorMessage());
		CString strTemp;
		strTemp.Format(HDevExpDefaultException.ErrorMessage());
		WriteLog(L"!!warning:" + strTemp);
	}
}

// 作为内存中的图片生在在程序界面上显示并且存储
void CLJX800AControlDlg::VecToImgSaveAndShow()
{
	//UpdateData(TRUE);
	DWORD startIndex = ProfileIndex;						// 限制是 2^16-1
	DWORD dataCount = (DWORD)_ttol(ProfileCount);			// 限制是 2^16-1
	GetDlgItem(IDC_STA_ADDPATH)->GetWindowTextW(SaveFilePath);

	// 共享指针创建生成内存的图像
	std::shared_ptr<HObject> hoHeightPtr = std::make_shared<HObject>();
	std::shared_ptr<HObject> hoIntensPtr = std::make_shared<HObject>();

	if (m_aDeviceData[m_nCurrentDeviceID].m_simpleArrayStoreHighSpeed.
		VerProfileToImage(hoHeightPtr, hoIntensPtr,startIndex, dataCount))
	{
		if (BST_CHECKED == IsDlgButtonChecked(IDC_CHK_CHOOSESAVEIMG))
		{
			if (((CButton *)GetDlgItem(IDC_RAD_PLC))->GetCheck())
			{
				CString fileName = LoopPLCFileName(hv_a.I(), SaveFilePath);
				SaveFilePath = fileName;
			}

			if (TestFileIsHave(SaveFilePath))
			{
				
				// 线程的执行时间是不确定的
				// 向线程中传入参数时，尽量保证只传临时参数，不要传成员变量

				/*std::thread thread_SaveImg_Height(&CLJX800AControlDlg::SaveImg, this,
					1, hv_a.I(), hoHeightPtr);
				thread_SaveImg_Height.detach();

				std::thread thread_SaveImg_Intens(&CLJX800AControlDlg::SaveImg, this,
					2, hv_a.I(), hoIntensPtr);
				thread_SaveImg_Intens.detach();*/

				//SaveImg(1, m_aDeviceData[m_nCurrentDeviceID].m_simpleArrayStoreHighSpeed.ho_Height);
				//SaveImg(2, m_aDeviceData[m_nCurrentDeviceID].m_simpleArrayStoreHighSpeed.ho_Intens);

				// 线程池的方法
				m_ThreadPool.enqueue(&CLJX800AControlDlg::SaveImg, this,
					1, SaveFilePath, hv_a.I(), hoHeightPtr);
				m_ThreadPool.enqueue(&CLJX800AControlDlg::SaveImg, this,
					2, SaveFilePath, hv_a.I(), hoIntensPtr);
				lRcState = LJX8IF_RC_OK;
				

				if (lRcState == LJX8IF_RC_OK)
				{
					CString temp = L"保存第_";
					temp.Append(hv_a.TupleString(".2d").S());
					temp.Append(L"_张照片完成。");
					WriteLog(temp);
				}
			}
			else
			{
				WriteLog(L"文件夹创建失败，图片未保存");
				lRcState = LJX8IF_RC_ERR_NOT_OPEN;
			}
		}

		if(BST_CHECKED != IsDlgButtonChecked(IDC_CHK_CHOOSESAVEIMG))
		{
			CString temp = L"拍摄第_";
			temp.Append(hv_a.TupleString(".2d").S());
			temp.Append(L"_张照片完成。");
			WriteLog(temp);
		}

		try
		{
			OnDrawShowInfoSize(1, hoHeightPtr);
			HalconCpp::DispObj(*hoHeightPtr, hv_windowhandle1);

			OnDrawShowInfoSize(2, hoIntensPtr);
			HalconCpp::DispObj(*hoIntensPtr, hv_windowhandle2);
	
		}
		catch (HalconCpp::HException& HDevExpDefaultException)
		{
			//printf(HDevExpDefaultException.ErrorMessage());
			CString strTemp; 
			strTemp.Format(HDevExpDefaultException.ErrorMessage());
			WriteLog(L"!!warning:" + strTemp);
		}

		//CProfileSimpleArrayStore proArray;
		//delete proArray.ho_Height;
		//delete proArray.ho_Intens;
		//vector<byte>().swap(proArray.mem_Height);
		//vector<byte>().swap(proArray.mem_Intens);
		//m_aDeviceData[m_nCurr entDeviceID].m_simpleArrayStoreHighSpeed.mem_Height.swap(vector<int>());
	}
}

// 开启相机
void CLJX800AControlDlg::OnBnClickedBtnOpencam()
{
	// TODO: 在此添加控件通知处理程序代码
	Clear_StopMark = FALSE;
	isCamOpen = FALSE;

	//以输入的触发间隔来获取数据
	//SetTimer(TimeTriggerStartID, TriggerTimerInterval, NULL);

	//作用选择要保存的文件的路径
	//ChooseSavePatSingle();
	//if (lRcState != LJX8IF_RC_OK) return;

	//初始化DLL库
	InitializeDLL();
	if (lRcState != LJX8IF_RC_OK) return;

	//初始化以太网连接地址
	OpenEthernetSingle();
	if (lRcState != LJX8IF_RC_OK) return;

	//初始化以太网高速连接（简单数组)
	//相比上一个以太网连接，多了一个高速以太网连接端口
	InitializehighspeeddatacommunicationSimplearray();
	if (lRcState != LJX8IF_RC_OK) return;

	//准备以太网高速连接
	//有些操作现在还是不明确有没有用，不知道能不能省略掉
	//相比上一个，只为了获取轮廓数扫描的起始位置
	Prestarthighspeeddatacommunication();
	if (lRcState != LJX8IF_RC_OK) return;

	//开始以太网高速连接
	Starthighspeeddatacommunication();
	if (lRcState != LJX8IF_RC_OK) return;

	isCamOpen = TRUE;
	WriteLog(L"打开相机成功");
}

// 开始采集
void CLJX800AControlDlg::OnBnClickedBtnStartcam()
{
	// TODO: 在此添加控件通知处理程序代码
	isMOXOnBoder = FALSE;
	isPauseBtn = FALSE;
	
	if (isCamOpen)
	{
		Clear_StopMark = 0;

		// 开始测量
		Startmeasure();

		//清除定时器
		/*while (!ReceiveEnough);
		KillTimer(SaveImgID);*/
	}
	else
	{
		WriteLog(L"启动测量错误！！");
		return;
	}
}

// 关闭相机
void CLJX800AControlDlg::OnBnClickedBtnClosecam()
{
	// TODO: 在此添加控件通知处理程序代码

	//Clear_StopMark = 1;
	isCamOpen = FALSE;
	isPauseBtn = TRUE;
	XSleep(350);

	if (Clear_StopMark)
	{
		hv_a = 1;
		//isCamOpen = 0;

		Stophighspeeddatacommunication();
		Finalizehighspeeddatacommunication();

		LJX8IF_Finalize();
		WriteLog(L"关闭相机成功。");
	}
	else
	{
		isCamOpen = TRUE;
		isPauseBtn = FALSE;
		WriteLog(L"有正在收集的亮度信息,关闭相机错误！！1s之后自动重试。");
		XSleep(1000);
		OnBnClickedBtnClosecam();
	}
}

void CLJX800AControlDlg::OnTimer(UINT_PTR nIDEvent)
{
	// TODO: 在此添加消息处理程序代码和/或调用默认值
	// WM_TIMER windows 消息 WINDOWS消息不可靠 会丢 WM_TIMER消息的优先级很低

	//循环采集消息
	//if (nIDEvent == TimeTriggerStartID)
	//{
	//	int nBatchNo = 0;  //拍摄样品序号
	//	DWORD dwNotify = 0;  //当值为00010000表示拍摄完成

	//	//作用好像仅仅是更新状态框
	//	for (int i = 0; i < LJX8IF_GUI_DEVICE_COUNT; i++)
	//	{
	//		if (m_bIsUseSimpleArray) {
	//			m_anProfReceiveCount[i] = m_aDeviceData[i].m_simpleArrayStoreHighSpeed.GetCount();
	//			dwNotify = m_aDeviceData[i].m_simpleArrayStoreHighSpeed.GetNotify();
	//			nBatchNo = m_aDeviceData[i].m_simpleArrayStoreHighSpeed.m_nBatchNo;
	//		}
	//		else
	//		{
	//			CThreadSafeBuffer* threadSafeBuf = CThreadSafeBuffer::getInstance();
	//			vector<PROFILE_DATA> vecProfileData;
	//			threadSafeBuf->Get(i, &dwNotify, &nBatchNo, vecProfileData);

	//			if (vecProfileData.size() == 0 && dwNotify == 0) continue;

	//			for (unsigned int j = 0; j < vecProfileData.size(); j++)
	//			{
	//				if (m_aDeviceData[i].m_vecProfileDataHighSpeed.size() < BUFFER_FULL_COUNT)
	//				{
	//					m_aDeviceData[i].m_vecProfileDataHighSpeed.push_back(vecProfileData.at(j));
	//				}
	//				m_anProfReceiveCount[i]++;
	//			}
	//		}

	//		if (dwNotify == 0) continue;

	//		/*CString strLog;
	//		strLog.Format(_T("notify[%d] = 0x%08X \tbatch[%d] \r\n"), i, dwNotify, nBatchNo);
	//		m_strCommandLog += (LPCTSTR)strLog;
	//		UpdateData(FALSE);
	//		m_txtCommandLog.LineScroll(m_txtCommandLog.GetLineCount());*/
	//	}

	//	//暂时决定在50ms那个定时器里面检测，不在外面重复更新了
	//	//UpDateReceiveCount();
	//}

	//指示操作时间超时
	if (nIDEvent == BufferFullID)
	{
		for (int i = 0; i < LJX8IF_GUI_DEVICE_COUNT; i++)
		{
			if ((m_bIsBufferFull[i]) && (!m_bIsStopCommunicationByError[i]))
			{
				m_bIsStopCommunicationByError[i] = true;
				LJX8IF_StopHighSpeedDataCommunication(i);
				LJX8IF_FinalizeHighSpeedDataCommunication(i);

				KillTimer(7);

				AfxMessageBox(_T("receive buffer is full."));
			}
		}
	}

	//计算收集轮廓的总数，当达到要求的轮廓数的时候，自动点击停止测量按钮
	if (nIDEvent == SaveImgID)
	{
		HaveReceiveProfNum = m_aDeviceData[m_nCurrentDeviceID].m_simpleArrayStoreHighSpeed.GetCount();

		if (ProfileCountNum == HaveReceiveProfNum)
		{
			KillTimer(SaveImgID);

			Clear_StopMark = true;
			ReceiveEnough = true;

			Stopmeasure();
			VecToImgSaveAndShow();
			//std::thread thread_SaveImg(&CLJX800AControlDlg::Hispeedsaveasbitmapfile,this);
			//thread_SaveImg.detach();
			//Hispeedsaveasbitmapfile();

			/*CString temp = L"拍摄第_";
			temp.Append(hv_a.TupleString(".2d").S());
			temp.Append(L"_张照片");
			WriteLog(temp);*/
			if (lRcState == LJX8IF_RC_OK)
			{
				CString str;
				GetDlgItem(IDC_STA_SAVENUM)->GetWindowTextW(str);
				if (hv_a.I() == _ttoi(str) && IsDlgButtonChecked(IDC_CHK_ISSAVEFROMNUM))
					OnBnClickedBtnClosecam();
				else
				{
					ChangeSaveFileName();

					//方法0
					if (LJX8IF_RC_OK != LJX8IF_ClearMemory(m_nCurrentDeviceID))
						WriteLog(L"内存清除错误");

					//方法1
					ClearAllHighspeedBuffer(m_nCurrentDeviceID);

					Stophighspeeddatacommunication();
					Finalizehighspeeddatacommunication();

					InitializehighspeeddatacommunicationSimplearray();
					Prestarthighspeeddatacommunication();
					Starthighspeeddatacommunication();

					//SetTimer(7, 300, NULL);
					// 默认选择多次采集
					if (!isPauseBtn)
					{
						if (BST_CHECKED == IsDlgButtonChecked(IDC_CHK_ISSETPBYMORE))
						{
							OnBnClickedBtnStartcam();
						}
					}
				}
			}
			else
			{
				// TODO 拍摄异常后将要执行的操作
				//OnBnClickedBtnStartcam();
			}
		}
		// 办法2
		//if (m_bIsUseSimpleArray == TRUE) {
		// m_aDeviceData[m_nCurrentDeviceID].m_simpleArrayStoreHighSpeed.m_nDataWidth =
		//  m_aProfileInfo[m_nCurrentDeviceID].wProfileDataCount;
		// m_aDeviceData[m_nCurrentDeviceID].m_simpleArrayStoreHighSpeed.m_bIsLuminanceEnable =
		//  m_aProfileInfo[m_nCurrentDeviceID].byLuminanceOutput == 1;
		//}
	}

	

	CDialogEx::OnTimer(nIDEvent);
}

void CLJX800AControlDlg::OnEnChangeLogshowEdit()
{
	// TODO:  如果该控件是 RICHEDIT 控件，它将不
	// 发送此通知，除非重写 CDialogEx::OnInitDialog()
	// 函数并调用 CRichEditCtrl().SetEventMask()，
	// 同时将 ENM_CHANGE 标志“或”运算到掩码中。

	// TODO:  在此添加控件通知处理程序代码
	if (isCamOpen)
	{
		GetDlgItem(IDC_BTN_CLOSECAM)->EnableWindow(1);
		GetDlgItem(IDC_BTN_STARTCAM)->EnableWindow(1);

		GetDlgItem(IDC_BUT_CHOOSESAVEPATH)->EnableWindow(0);
		GetDlgItem(IDC_BTN_OPENCAM)->EnableWindow(0);
	}

	if (!isCamOpen)
	{
		GetDlgItem(IDC_BTN_STARTCAM)->EnableWindow(0);
		GetDlgItem(IDC_BTN_CLOSECAM)->EnableWindow(0);

		GetDlgItem(IDC_BTN_OPENCAM)->EnableWindow(1);
		GetDlgItem(IDC_BUT_CHOOSESAVEPATH)->EnableWindow(1);
	}
	
	// 20次约是1600
	auto TextNum = GetDlgItem(IDC_LOGSHOW_EDIT)->GetWindowTextLengthW();

	if (10000 < TextNum)
		GetDlgItem(IDC_LOGSHOW_EDIT)->SetWindowTextW(L"");

	/*if (ReceiveEnough)
		KillTimer(SaveImgID);*/
}

void CLJX800AControlDlg::OnDestroy()
{
	CDialogEx::OnDestroy();

	// TODO: 在此处添加消息处理程序代码

	KillTimer(BufferFullID);
	//KillTimer(TimeTriggerStartID);
	KillTimer(SaveImgID);

	OnBnClickedBtnClosecam();
}

void CLJX800AControlDlg::OnBnClickedButton1()
{
	// TODO: 在此添加控件通知处理程序代码
	Startmeasure();
}

void CLJX800AControlDlg::OnBnClickedButton3()
{
	// TODO: 在此添加控件通知处理程序代码
	Stopmeasure();
}

void CLJX800AControlDlg::OnBnClickedButton2()
{
	// TODO: 在此添加控件通知处理程序代码
	HaveReceiveProfNum = m_aDeviceData[0].m_simpleArrayStoreHighSpeed.GetCount();

	if (ProfileCountNum == HaveReceiveProfNum)
	{
		Hispeedsaveasbitmapfile();
		//m_aDeviceData[0].m_simpleArrayStoreHighSpeed.Clear();
		if (LJX8IF_RC_OK != LJX8IF_ClearMemory(0))
			WriteLog(L"内存清除错误");

		Clear_StopMark = 1;
	}
}

void CLJX800AControlDlg::OnBnClickedButLoopstart()
{
	// TODO: 在此添加控件通知处理程序代码

	/*OnBnClickedBtnOpencam();
	OnBnClickedBtnStartcam();
	SetTimer(6, 1000, NULL);*/

	//SetTimer(7, 400, NULL);
	
	/*string strTest;
	strTest = CT2A(SaveFilePath.GetString());

	if (CreateDirByName(strTest))
	{
		WriteLog(L"创建位置成功");
	}*/

	//XSleep(10000);
	UpdateData(TRUE);
	GetDlgItem(IDC_STA_ADDPATH)->GetWindowTextW(SaveFilePath);

	for (auto i = 1; i <= MOXNum; i++)
	{
		CString num;
		CString heightPath = SaveFilePath;
		CString intensPath = SaveFilePath;
		num.Format(L"\\%d", i);
		heightPath.Append(num);
		heightPath.Append(L"\\height");
		intensPath.Append(num);
		intensPath.Append(L"\\intens");

		//返回true表示没有这个文件夹
		if (GetFileAttributes(heightPath))
		{
			// 返回true表示创建成功
			if (!CreateDirByName(heightPath))
			{
				WriteLog(L"创建高度值文件夹失败，保存失败!!!");
				lRcState = LJX8IF_RC_ERR_NOT_OPEN;
				//return;
			}
		}

		if (GetFileAttributes(intensPath))
		{
			// 返回true表示创建成功
			if (!CreateDirByName(intensPath))
			{
				WriteLog(L"创建亮度值文件夹失败，保存失败!!!");
				lRcState = LJX8IF_RC_ERR_NOT_OPEN;
				//return;
			}
		}
	}

	WriteLog(L"创建文件夹成功");
}

// 暂停拍摄操作
void CLJX800AControlDlg::OnBnClickedBtnPausecam()
{
	// TODO: 在此添加控件通知处理程序代码
 	CString puase = L"暂停";
	CString start = L"重新开始";

	CString now = L"";
	UpdateData(TRUE);
	GetDlgItem(IDC_BTN_PAUSECAM)->GetWindowText(now);

	// 单击了暂停
	if (puase == now)
	{
		isPauseBtn = TRUE;
		isMOXOnBoder = FALSE;
		GetDlgItem(IDC_BTN_PAUSECAM)->SetWindowText(L"重新开始");
		WriteLog(L"程序已暂停");
		return;
	}

	// 单击了重新开始
	if (start == now)
	{
		isPauseBtn = FALSE;
		isMOXOnBoder = FALSE;
		GetDlgItem(IDC_BTN_PAUSECAM)->SetWindowText(L"暂停");
		WriteLog(L"程序重新开始");
		if (isCamOpen)
			OnBnClickedBtnStartcam();
		SetTimer(SaveImgID, SaveImgIDInterval, NULL);
		return;
	}
}

// 获取日志文本然后置空
void CLJX800AControlDlg::OnBnClickedButCleanlog()
{
	// TODO: 在此添加控件通知处理程序代码
	UpdateData(TRUE);
	GetDlgItem(IDC_LOGSHOW_EDIT)->SetWindowTextW(L"");
}

// 点击了非PLC采集
void CLJX800AControlDlg::OnBnClickedRadNotplc()
{
	// TODO: 在此添加控件通知处理程序代码
	if (::SendMessage(::GetDlgItem(m_hWnd, IDC_RAD_NOTPLC), BM_GETCHECK, NULL, NULL) == BST_CHECKED)
	{
		//MessageBox(_T("选择了单选按钮1!"), NULL, MB_ICONINFORMATION);//弹出提示
		GetDlgItem(IDC_BTN_STARTCAM)->EnableWindow(TRUE);

		GetDlgItem(IDC_BTN_STARTCAM)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_BTN_PAUSECAM)->ShowWindow(SW_SHOW);
		((CButton *)GetDlgItem(IDC_CHK_ISSETPBYMORE))->SetCheck(TRUE);
		GetDlgItem(IDC_CHK_ISSETPBYMORE)->EnableWindow(TRUE);
		((CButton *)GetDlgItem(IDC_CHK_ISSAVEFROMNUM))->SetCheck(TRUE);
		GetDlgItem(IDC_CHK_ISSAVEFROMNUM)->EnableWindow(TRUE);
		GetDlgItem(IDC_STA_SAVENUM)->EnableWindow(TRUE);

		WriteLog(L"选择非PLC状态采集.");
	}
}

// 点击了PLC采集
void CLJX800AControlDlg::OnBnClickedRadPlc()
{
	// TODO: 在此添加控件通知处理程序代码
	if (::SendMessage(::GetDlgItem(m_hWnd, IDC_RAD_PLC), BM_GETCHECK, NULL, NULL) == BST_CHECKED)
	{
		//MessageBox(_T("选择了单选按钮2!"), NULL, MB_ICONINFORMATION);//弹出提示
		//GetDlgItem(IDC_BTN_STARTCAM)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_STARTCAM)->ShowWindow(SW_HIDE);

		GetDlgItem(IDC_BTN_PAUSECAM)->ShowWindow(SW_HIDE);
		((CButton *)GetDlgItem(IDC_CHK_ISSETPBYMORE))->SetCheck(FALSE);
		GetDlgItem(IDC_CHK_ISSETPBYMORE)->EnableWindow(FALSE);
		//GetDlgItem(IDC_CHK_ISSAVEFROMNUM)->EnableWindow(FALSE);
		//GetDlgItem(IDC_STA_SAVENUM)->EnableWindow(FALSE);

		WriteLog(L"选择PLC状态采集.");
	}
}

// 更改保存图片数量
void CLJX800AControlDlg::OnEnChangeStaSavenum()
{
	// TODO:  如果该控件是 RICHEDIT 控件，它将不
	// 发送此通知，除非重写 CDialogEx::OnInitDialog()
	// 函数并调用 CRichEditCtrl().SetEventMask()，
	// 同时将 ENM_CHANGE 标志“或”运算到掩码中。

	// TODO:  在此添加控件通知处理程序代码
	//UpdateData(TRUE);
	CString tmp;
	GetDlgItem(IDC_STA_SAVENUM)->GetWindowTextW(tmp);
	SaveImgCount = _ttoi(tmp);

	WriteLog(L"当前选择的存图数量为：" + tmp);
}


void CLJX800AControlDlg::OnBnClickedButTest()
{
	// TODO: 在此添加控件通知处理程序代码
	HalconCpp::HObject ho_Height, ho_Intensity;
	std::shared_ptr<HObject> hoHeightPtr = std::make_shared<HObject>();
	std::shared_ptr<HObject> hoIntensPtr = std::make_shared<HObject>();

	CString height = L"D:\\DataBase\\20191211\\20191229_21 7 6_00783_height.tiff";
	CString intens = L"D:\\DataBase\\20191211\\20191229_21 7 6_00783_intens.tiff";

	ReadImage(hoHeightPtr.get(), height.GetBuffer());
	ReadImage(hoIntensPtr.get(), intens.GetBuffer());

	mg_DealCam->ToStartCamDeal(hoHeightPtr, hoIntensPtr,
		hv_windowhandle3, hv_windowhandle4, this);

	//mg_DealCam->ToStartCamDeal(hoHeightPtr, hoIntensPtr);
	/**hoHeightPtr = mg_DealCam->ho_DJ_Out;
	*hoIntensPtr = mg_DealCam->ho_QX_Out;*/

	//OnDrawShowInfoSize(3, hoHeightPtr);
	//HalconCpp::DispObj(*hoIntensPtr, hv_windowhandle3);

	//OnDrawShowInfoSize(4, hoHeightPtr);
	//HalconCpp::DispObj(*hoIntensPtr, hv_windowhandle4);

	
}
