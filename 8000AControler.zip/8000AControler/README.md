# 8000A-SelfControl
8000A自定义控制端

IDC_LOGSHOW_EDIT控件ID